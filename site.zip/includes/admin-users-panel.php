<?php
/**
 * NéoPcPro – Panneaux admin pour gestion utilisateurs et commentaires
 * À inclure depuis admin-panel.php
 */
if (!defined('NEOPCPRO_LOADED')) {
    http_response_code(403);
    exit;
}
?>

<!-- ── Utilisateurs ──────────────────────────────────────────────── -->
<section class="admin-tab-panel<?php echo $activeAdminTab === 'users' ? ' is-active' : ''; ?>" data-admin-tab-panel="users">
    <div class="admin-form-card">
        <h3>Gestion des Utilisateurs</h3>
        <p class="admin-form-text">Validez les inscriptions, gérez les statuts et consultez l'historique des connexions.</p>
        
        <!-- Statistiques -->
        <div class="user-stats-grid">
            <div class="user-stat-card">
                <div class="user-stat-label">Total</div>
                <div class="user-stat-value"><?php echo count($users); ?></div>
            </div>
            <div class="user-stat-card stat-pending">
                <div class="user-stat-label">En attente</div>
                <div class="user-stat-value"><?php echo $pendingUsersCount; ?></div>
            </div>
            <div class="user-stat-card stat-active">
                <div class="user-stat-label">Actifs</div>
                <div class="user-stat-value"><?php echo count(array_filter($users, fn($u) => $u['status'] === 'active')); ?></div>
            </div>
            <div class="user-stat-card stat-banned">
                <div class="user-stat-label">Bannis</div>
                <div class="user-stat-value"><?php echo count(array_filter($users, fn($u) => $u['status'] === 'banned')); ?></div>
            </div>
        </div>
        
        <?php if (empty($users)): ?>
            <div class="admin-empty-state">
                <p>Aucun utilisateur inscrit pour le moment.</p>
            </div>
        <?php else: ?>
        
        <!-- Liste des utilisateurs -->
        <div class="users-table-wrapper">
            <table class="users-table">
                <thead>
                    <tr>
                        <th>Statut</th>
                        <th>Utilisateur</th>
                        <th>Email</th>
                        <th>Inscription</th>
                        <th>Dernière connexion</th>
                        <th>Source</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $user): ?>
                    <tr class="user-row status-<?php echo $user['status']; ?>">
                        <td>
                            <span class="status-badge status-<?php echo $user['status']; ?>">
                                <?php 
                                    $statusLabels = ['pending' => '⏳ En attente', 'active' => '✓ Actif', 'banned' => '⛔ Banni'];
                                    echo $statusLabels[$user['status']] ?? $user['status'];
                                ?>
                            </span>
                        </td>
                        <td><strong><?php echo escape($user['username']); ?></strong></td>
                        <td><?php echo escape($user['email']); ?></td>
                        <td><?php 
                            $date = strtotime($user['created_at']);
                            echo $date ? date('d/m/Y H:i', $date) : escape($user['created_at']);
                        ?></td>
                        <td><?php 
                            if ($user['last_login']) {
                                $date = strtotime($user['last_login']);
                                echo $date ? date('d/m/Y H:i', $date) : escape($user['last_login']);
                            } else {
                                echo '<span style="color:#64748b;">Jamais</span>';
                            }
                        ?></td>
                        <td><?php echo $user['discovered_from'] ? escape($user['discovered_from']) : '<span style="color:#64748b;">—</span>'; ?></td>
                        <td>
                            <div class="user-actions">
                                <?php if ($user['status'] === 'pending'): ?>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                                        <input type="hidden" name="admin_action" value="validate_user">
                                        <input type="hidden" name="user_id" value="<?php echo escapeAttribute($user['id']); ?>">
                                        <button type="submit" class="user-action-btn btn-validate" title="Valider">✓</button>
                                    </form>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                                        <input type="hidden" name="admin_action" value="reject_user">
                                        <input type="hidden" name="user_id" value="<?php echo escapeAttribute($user['id']); ?>">
                                        <button type="submit" class="user-action-btn btn-reject" title="Refuser" onclick="return confirm('Refuser cette inscription ?')">✕</button>
                                    </form>
                                <?php elseif ($user['status'] === 'active'): ?>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                                        <input type="hidden" name="admin_action" value="ban_user">
                                        <input type="hidden" name="user_id" value="<?php echo escapeAttribute($user['id']); ?>">
                                        <button type="submit" class="user-action-btn btn-ban" title="Bannir" onclick="return confirm('Bannir cet utilisateur ?')">⛔</button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                                        <input type="hidden" name="admin_action" value="unban_user">
                                        <input type="hidden" name="user_id" value="<?php echo escapeAttribute($user['id']); ?>">
                                        <button type="submit" class="user-action-btn btn-unban" title="Débannir">✓</button>
                                    </form>
                                <?php endif; ?>
                                
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                                    <input type="hidden" name="admin_action" value="delete_user">
                                    <input type="hidden" name="user_id" value="<?php echo escapeAttribute($user['id']); ?>">
                                    <button type="submit" class="user-action-btn btn-delete" title="Supprimer" onclick="return confirm('Supprimer définitivement cet utilisateur et tous ses commentaires ?')">🗑</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        
        <!-- Historique des connexions -->
        <div class="login-history-section">
            <h4>Historique des Connexions</h4>
            <?php if (empty($loginHistory)): ?>
                <p style="color:#94a3b8;">Aucune connexion enregistrée.</p>
            <?php else: ?>
                <p style="margin-bottom:1rem;color:#94a3b8;font-size:0.9rem;">
                    Affichage des 20 dernières connexions (<?php echo count($loginHistory); ?> au total).
                </p>
                <div class="history-table-wrapper">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Utilisateur</th>
                                <th>Date & Heure</th>
                                <th>Adresse IP</th>
                                <th>Navigateur</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach (array_slice($loginHistory, 0, 20) as $entry): ?>
                            <tr>
                                <td><strong><?php echo escape($entry['username']); ?></strong></td>
                                <td><?php 
                                    $date = strtotime($entry['timestamp']);
                                    echo $date ? date('d/m/Y à H:i:s', $date) : escape($entry['timestamp']);
                                ?></td>
                                <td><code><?php echo escape($entry['ip_address']); ?></code></td>
                                <td style="font-size:0.85rem;color:#94a3b8;"><?php echo escape(substr($entry['user_agent'], 0, 60)); ?><?php echo strlen($entry['user_agent']) > 60 ? '...' : ''; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <form method="POST" style="margin-top:1rem;">
                    <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action" value="purge_login_history">
                    <button type="submit" class="admin-danger-button" onclick="return confirm('Purger tout l\'historique de connexion ?')">
                        Purger l'historique
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <!-- Configuration du système utilisateurs -->
        <div class="admin-subsection">
            <div class="admin-subsection-heading">
                <h4>Configuration du système utilisateurs</h4>
                <p class="admin-form-text">Gérez les paramètres d'accès, d'inscription et les messages affichés aux visiteurs.</p>
            </div>
            <form method="POST" class="admin-form-card">
                <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="save_user_config">
                <div class="admin-form-grid">
                    <label class="admin-field admin-field-checkbox admin-field-full">
                        <input type="checkbox" name="private_mode_enabled" value="1" <?php echo ((int)($userConfig['private_mode_enabled'] ?? 1) === 1) ? 'checked' : ''; ?>>
                        <span>Mode privé — les visiteurs non connectés doivent se connecter pour voir le site</span>
                    </label>
                    <label class="admin-field admin-field-checkbox admin-field-full">
                        <input type="checkbox" name="allow_registration" value="1" <?php echo ((int)($userConfig['allow_registration'] ?? 1) === 1) ? 'checked' : ''; ?>>
                        <span>Autoriser les inscriptions</span>
                    </label>
                    <label class="admin-field admin-field-full"><span>Message de connexion</span>
                        <input type="text" name="login_message" value="<?php echo escapeAttribute($userConfig['login_message'] ?? ''); ?>">
                    </label>
                    <label class="admin-field admin-field-full"><span>Message d'inscription</span>
                        <input type="text" name="registration_message" value="<?php echo escapeAttribute($userConfig['registration_message'] ?? ''); ?>">
                    </label>
                    <label class="admin-field admin-field-full"><span>Message de bienvenue (après inscription)</span>
                        <input type="text" name="welcome_message" value="<?php echo escapeAttribute($userConfig['welcome_message'] ?? ''); ?>">
                    </label>
                </div>
                <div class="admin-form-actions">
                    <button class="admin-save-button" type="submit">Enregistrer la configuration</button>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- ── Commentaires ─────────────────────────────────────────────── -->
<section class="admin-tab-panel<?php echo $activeAdminTab === 'comments' ? ' is-active' : ''; ?>" data-admin-tab-panel="comments">
    <div class="admin-form-card">
        <h3>Modération des Commentaires</h3>
        <p class="admin-form-text">Approuvez, rejetez ou supprimez les commentaires laissés par les utilisateurs.</p>
        
        <!-- Statistiques commentaires -->
        <div class="user-stats-grid">
            <div class="user-stat-card">
                <div class="user-stat-label">Total</div>
                <div class="user-stat-value"><?php echo count($comments); ?></div>
            </div>
            <div class="user-stat-card stat-pending">
                <div class="user-stat-label">En attente</div>
                <div class="user-stat-value"><?php echo $pendingCommentsCount; ?></div>
            </div>
            <div class="user-stat-card stat-active">
                <div class="user-stat-label">Approuvés</div>
                <div class="user-stat-value"><?php echo count(array_filter($comments, fn($c) => $c['status'] === 'approved')); ?></div>
            </div>
            <div class="user-stat-card stat-banned">
                <div class="user-stat-label">Rejetés</div>
                <div class="user-stat-value"><?php echo count(array_filter($comments, fn($c) => $c['status'] === 'rejected')); ?></div>
            </div>
        </div>
        
        <?php if (empty($comments)): ?>
            <div class="admin-empty-state">
                <p>Aucun commentaire pour le moment.</p>
            </div>
        <?php else: ?>
        
        <!-- Liste des commentaires -->
        <div class="comments-list">
            <?php foreach ($comments as $comment): ?>
            <?php
                // Trouver l'article associé
                $article = null;
                foreach ($newsArticles as $a) {
                    if ($a['id'] === $comment['article_id']) {
                        $article = $a;
                        break;
                    }
                }
            ?>
            <div class="comment-card status-<?php echo $comment['status']; ?>">
                <div class="comment-header">
                    <span class="status-badge status-<?php echo $comment['status']; ?>">
                        <?php 
                            $statusLabels = ['pending' => '⏳ En attente', 'approved' => '✓ Approuvé', 'rejected' => '✕ Rejeté'];
                            echo $statusLabels[$comment['status']] ?? $comment['status'];
                        ?>
                    </span>
                    <div class="comment-meta">
                        <strong><?php echo escape($comment['username']); ?></strong>
                        <span class="comment-separator">•</span>
                        <span><?php 
                            $date = strtotime($comment['created_at']);
                            echo $date ? date('d/m/Y à H:i', $date) : escape($comment['created_at']);
                        ?></span>
                        <?php if ($article): ?>
                        <span class="comment-separator">•</span>
                        <span>Article : <em><?php echo escape($article['title']); ?></em></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="comment-content">
                    <?php echo nl2br(escape($comment['content'])); ?>
                </div>
                
                <div class="comment-actions">
                    <?php if ($comment['status'] !== 'approved'): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                            <input type="hidden" name="admin_action" value="approve_comment">
                            <input type="hidden" name="comment_id" value="<?php echo escapeAttribute($comment['id']); ?>">
                            <button type="submit" class="comment-action-btn btn-approve">✓ Approuver</button>
                        </form>
                    <?php endif; ?>
                    
                    <?php if ($comment['status'] !== 'rejected'): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                            <input type="hidden" name="admin_action" value="reject_comment">
                            <input type="hidden" name="comment_id" value="<?php echo escapeAttribute($comment['id']); ?>">
                            <button type="submit" class="comment-action-btn btn-reject">✕ Rejeter</button>
                        </form>
                    <?php endif; ?>
                    
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="delete_comment">
                        <input type="hidden" name="comment_id" value="<?php echo escapeAttribute($comment['id']); ?>">
                        <button type="submit" class="comment-action-btn btn-delete" onclick="return confirm('Supprimer définitivement ce commentaire ?')">🗑 Supprimer</button>
                    </form>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
