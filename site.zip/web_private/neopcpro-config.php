<?php
/**
 * NéoPcPro utilise désormais un pilotage sans MySQL.
 *
 * Les contenus modifiables sont stockés dans :
 * - web_private/data/site-settings.json
 * - web_private/data/main-buttons.json
 * - web_private/data/downloads.json
 * - web_private/data/admin-links.json
 *
 * Le mot de passe administrateur est stocké dans :
 * - web_private/admin_access/admin-password.php
 */
