<?php
/**
 * Mot de passe administrateur NéoPcPro.
 * Ce fichier est chargé automatiquement par index.php.
 */
$adminAccessPasswordHash = '$2y$12$iqxN4j7VaqVNNGMAJCWln.ULEvao8xmoi8UevXclkarg/LnegMFs6';
