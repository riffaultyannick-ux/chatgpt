<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Rediriger si non connecté
if (!$isUserAuthenticated) {
    header('Location: /index.php?show_login=1');
    exit;
}

$flash = getFlash();

$ogTitle = 'Mon Profil – NéoPcPro';
$ogDesc  = 'Gérez votre profil utilisateur sur NéoPcPro.';
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/profil.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $ogDesc; ?>">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="<?php echo escape($ogTitle); ?>">
<meta property="og:description" content="<?php echo $ogDesc; ?>">
<meta property="og:site_name"   content="NéoPcPro">
<title>Mon Profil – NéoPcPro</title>
<link rel="stylesheet" href="assets/css/style.css?v=22">
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>

<main class="page">
<section class="hero">
<div class="hero-content">

<!-- Flash message -->
<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<h1 class="page-title">Mon Profil</h1>
<p class="page-subtitle">Gérez vos informations personnelles et paramètres de compte</p>

<!-- Informations utilisateur -->
<div class="profile-info-card">
    <h2>Informations du compte</h2>
    <div class="profile-info-grid">
        <div class="profile-info-item">
            <span class="profile-info-label">Nom d'utilisateur</span>
            <span class="profile-info-value"><?php echo escape($currentUsername); ?></span>
        </div>
        <div class="profile-info-item">
            <span class="profile-info-label">Email</span>
            <span class="profile-info-value"><?php echo escape($currentUser['email']); ?></span>
        </div>
        <div class="profile-info-item">
            <span class="profile-info-label">Statut</span>
            <span class="profile-status-badge status-<?php echo $currentUser['status']; ?>">
                <?php echo escape($currentUser['status']); ?>
            </span>
        </div>
        <div class="profile-info-item">
            <span class="profile-info-label">Membre depuis le</span>
            <span class="profile-info-value"><?php 
                $date = strtotime($currentUser['created_at']);
                echo $date ? date('d/m/Y à H:i', $date) : escape($currentUser['created_at']);
            ?></span>
        </div>
        <?php if ($currentUser['last_login']): ?>
        <div class="profile-info-item">
            <span class="profile-info-label">Dernière connexion</span>
            <span class="profile-info-value"><?php 
                $date = strtotime($currentUser['last_login']);
                echo $date ? date('d/m/Y à H:i', $date) : escape($currentUser['last_login']);
            ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modifier le profil -->
<div class="profile-edit-card">
    <h2>Modifier mon profil</h2>
    <form method="POST" class="profile-form">
        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="update_profile">
        
        <div class="profile-form-group">
            <label for="profile_email">Adresse email</label>
            <input 
                type="email" 
                id="profile_email" 
                name="profile_email" 
                value="<?php echo escapeAttribute($currentUser['email']); ?>"
                required
            >
            <small>Votre adresse email peut être modifiée à tout moment.</small>
        </div>
        
        <div class="profile-form-group">
            <label for="profile_password">Nouveau mot de passe (optionnel)</label>
            <input 
                type="password" 
                id="profile_password" 
                name="profile_password" 
                placeholder="Laissez vide pour ne pas changer"
                minlength="6"
                autocomplete="new-password"
            >
            <small>Minimum 6 caractères. Laissez vide si vous ne souhaitez pas changer votre mot de passe.</small>
        </div>
        
        <div class="profile-form-group">
            <label for="profile_password_confirm">Confirmer le nouveau mot de passe</label>
            <input 
                type="password" 
                id="profile_password_confirm" 
                name="profile_password_confirm" 
                placeholder="Confirmez votre nouveau mot de passe"
                minlength="6"
                autocomplete="new-password"
            >
        </div>
        
        <div class="profile-form-actions">
            <button type="submit" class="profile-save-btn">Enregistrer les modifications</button>
        </div>
    </form>
</div>

<!-- Zone dangereuse -->
<div class="profile-danger-card">
    <h2>Zone dangereuse</h2>
    <p>La suppression de votre compte est <strong>définitive et irréversible</strong>. Toutes vos données, y compris vos commentaires, seront supprimées.</p>
    
    <details class="profile-delete-details">
        <summary>Supprimer mon compte</summary>
        <div class="profile-delete-content">
            <p>⚠️ Cette action est <strong>irréversible</strong>. Veuillez confirmer en saisissant votre mot de passe actuel.</p>
            
            <form method="POST" class="profile-delete-form">
                <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="delete_account">
                
                <div class="profile-form-group">
                    <label for="delete_account_password">Mot de passe actuel</label>
                    <input 
                        type="password" 
                        id="delete_account_password" 
                        name="delete_account_password" 
                        placeholder="Confirmez avec votre mot de passe"
                        required
                        autocomplete="current-password"
                    >
                </div>
                
                <button 
                    type="submit" 
                    class="profile-delete-btn"
                    onclick="return confirm('Êtes-vous absolument sûr de vouloir supprimer votre compte ? Cette action est irréversible.');"
                >
                    Oui, supprimer définitivement mon compte
                </button>
            </form>
        </div>
    </details>
</div>

</div>
</section>
</main>

<style>
/* Styles spécifiques profil */
.page-title {
    font-size: clamp(1.8rem, 3vw, 2.5rem);
    font-weight: 900;
    color: #f8fafc;
    margin: 0 0 0.5rem 0;
}

.page-subtitle {
    font-size: 1rem;
    color: var(--muted);
    margin: 0 0 2rem 0;
}

.profile-info-card,
.profile-edit-card,
.profile-danger-card {
    margin-bottom: 2rem;
    padding: 1.5rem;
    border-radius: var(--radius-lg);
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.10);
}

.profile-info-card h2,
.profile-edit-card h2,
.profile-danger-card h2 {
    font-size: 1.3rem;
    font-weight: 800;
    color: #f8fafc;
    margin: 0 0 1rem 0;
}

.profile-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
}

.profile-info-item {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
}

.profile-info-label {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.03em;
}

.profile-info-value {
    font-size: 1rem;
    color: #e2e8f0;
}

.profile-status-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.4rem 0.8rem;
    border-radius: 999px;
    font-size: 0.85rem;
    font-weight: 700;
    width: fit-content;
}

.profile-status-badge.status-active {
    background: rgba(34, 197, 94, 0.15);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.30);
}

.profile-status-badge.status-pending {
    background: rgba(251, 191, 36, 0.15);
    color: #fbbf24;
    border: 1px solid rgba(251, 191, 36, 0.30);
}

.profile-form {
    display: flex;
    flex-direction: column;
    gap: 1.25rem;
}

.profile-form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.profile-form-group label {
    font-size: 0.9rem;
    font-weight: 600;
    color: #e2e8f0;
}

.profile-form-group input {
    padding: 0.75rem 1rem;
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.12);
    background: rgba(255, 255, 255, 0.04);
    color: #f8fafc;
    font-size: 0.95rem;
    transition: all 0.2s;
}

.profile-form-group input:focus {
    outline: none;
    border-color: rgba(56, 189, 248, 0.45);
    background: rgba(255, 255, 255, 0.07);
}

.profile-form-group small {
    font-size: 0.82rem;
    color: #94a3b8;
    line-height: 1.5;
}

.profile-form-actions {
    margin-top: 0.5rem;
}

.profile-save-btn {
    padding: 0.9rem 1.8rem;
    border-radius: 12px;
    border: none;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    font-size: 1rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
}

.profile-save-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 24px rgba(56, 189, 248, 0.35);
}

.profile-danger-card {
    border-color: rgba(239, 68, 68, 0.30);
    background: rgba(239, 68, 68, 0.05);
}

.profile-danger-card h2 {
    color: #fca5a5;
}

.profile-danger-card p {
    color: #cbd5e1;
    line-height: 1.6;
    margin: 0 0 1rem 0;
}

.profile-delete-details {
    margin-top: 1rem;
}

.profile-delete-details summary {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    background: rgba(239, 68, 68, 0.10);
    border: 1px solid rgba(239, 68, 68, 0.25);
    color: #fca5a5;
    font-weight: 600;
    cursor: pointer;
    user-select: none;
    transition: all 0.2s;
}

.profile-delete-details summary:hover {
    background: rgba(239, 68, 68, 0.15);
    border-color: rgba(239, 68, 68, 0.35);
}

.profile-delete-details[open] summary {
    margin-bottom: 1rem;
}

.profile-delete-content {
    padding: 1rem;
    border-radius: 8px;
    background: rgba(15, 23, 42, 0.50);
}

.profile-delete-content p {
    margin: 0 0 1rem 0;
}

.profile-delete-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.profile-delete-btn {
    padding: 0.9rem 1.5rem;
    border-radius: 8px;
    border: 1px solid #ef4444;
    background: #dc2626;
    color: white;
    font-size: 0.95rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
}

.profile-delete-btn:hover {
    background: #b91c1c;
    transform: translateY(-1px);
    box-shadow: 0 4px 16px rgba(239, 68, 68, 0.40);
}

@media (max-width: 639.98px) {
    .profile-info-card,
    .profile-edit-card,
    .profile-danger-card {
        padding: 1.25rem;
    }
}
</style>

</body>
</html>
