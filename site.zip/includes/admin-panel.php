<?php
/**
 * NéoPcPro – Panneau d'administration (pilotage du site)
 * Inclure uniquement depuis index.php.
 */
if (!defined('NEOPCPRO_LOADED')) {
    http_response_code(403);
    exit;
}

$adminTabOptions = [
    'general'     => 'Général',
    'buttons'     => 'Boutons',
    'admin-links' => 'Liens admin',
    'users'       => 'Utilisateurs',
    'comments'    => 'Commentaires',
    'maintenance' => 'Maintenance',
    'password'    => 'Mot de passe',
    'assets'      => 'Icônes & images',
    'access'      => 'Accès en écriture',
];
$activeAdminTab = (string) ($_GET['tab'] ?? 'general');
if (!array_key_exists($activeAdminTab, $adminTabOptions)) { $activeAdminTab = 'general'; }
$adminPanelTarget = '?panel=1&tab=' . rawurlencode($activeAdminTab) . '#admin-panel';
?>
<section class="admin-panel" id="admin-panel" aria-labelledby="admin-panel-title"
         data-admin-tabs data-active-tab="<?php echo escapeAttribute($activeAdminTab); ?>">

    <div class="admin-panel-header">
        <div>
            <p class="admin-panel-eyebrow">Administration</p>
            <h2 class="admin-panel-title" id="admin-panel-title"><?php echo escape($adminUi['dashboard_title'] ?? 'Pilotage du site'); ?></h2>
            <p class="admin-panel-text"><?php echo escape($adminUi['dashboard_text'] ?? ''); ?></p>
        </div>
        <div class="admin-panel-header-actions">
            <form method="post" class="admin-inline-form">
                <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="logout_return">
                <button class="admin-utility-link admin-utility-link-button" type="submit">Retour au site</button>
            </form>

        </div>
    </div>

    <?php if ($flash !== []): ?>
    <div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
        <?php echo escape($flash['message'] ?? ''); ?>
    </div>
    <?php endif; ?>

    <nav class="admin-tabs" aria-label="Sections du pilotage">
        <?php foreach ($adminTabOptions as $tabKey => $tabLabel): ?>
        <button
            class="admin-tab-button<?php echo $activeAdminTab === $tabKey ? ' is-active' : ''; ?>"
            type="button"
            data-admin-tab-trigger
            data-tab="<?php echo escapeAttribute($tabKey); ?>"
            aria-pressed="<?php echo $activeAdminTab === $tabKey ? 'true' : 'false'; ?>"
        ><?php echo escape($tabLabel); ?></button>
        <?php endforeach; ?>
    </nav>

    <div class="admin-panel-grid">

        <!-- ── Général ─────────────────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'general' ? ' is-active' : ''; ?>" data-admin-tab-panel="general">
            <form method="post" class="admin-form-card">
                <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action"  value="save_general">
                <h3>Réglages généraux</h3>
                <p class="admin-form-text">Modifie les textes principaux, les métadonnées Open Graph et les libellés d'administration.</p>
                <div class="admin-form-grid">
                    <label class="admin-field"><span>Titre principal</span>
                        <input type="text" name="site_title" value="<?php echo escapeAttribute($siteSettings['site_title'] ?? ''); ?>" required>
                    </label>
                    <label class="admin-field admin-field-full"><span>Sous-titre</span>
                        <textarea name="site_subtitle" rows="3"><?php echo escape($siteSettings['site_subtitle'] ?? ''); ?></textarea>
                    </label>
                    <label class="admin-field admin-field-full"><span>Image Open Graph (URL ou chemin assets/images/…)</span>
                        <input type="text" name="og_image" value="<?php echo escapeAttribute($siteSettings['og_image'] ?? ''); ?>" placeholder="https://… ou assets/images/…">
                    </label>
                    <label class="admin-field"><span>Bouton accès administrateur</span><input type="text" name="admin_button_label" value="<?php echo escapeAttribute($adminUi['button_label'] ?? ''); ?>"></label>
                    <label class="admin-field"><span>Titre fenêtre admin</span><input type="text" name="admin_modal_title" value="<?php echo escapeAttribute($adminUi['modal_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Texte d\'aide fenêtre admin</span><textarea name="admin_help_text" rows="2"><?php echo escape($adminUi['help_text'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Placeholder mot de passe</span><input type="text" name="admin_password_placeholder" value="<?php echo escapeAttribute($adminUi['password_placeholder'] ?? ''); ?>"></label>
                    <label class="admin-field"><span>Libellé déconnexion</span><input type="text" name="admin_logout_label" value="<?php echo escapeAttribute($adminUi['logout_label'] ?? ''); ?>"></label>
                    <label class="admin-field"><span>Libellé bouton pilotage</span><input type="text" name="admin_dashboard_label" value="<?php echo escapeAttribute($adminUi['dashboard_label'] ?? ''); ?>"></label>
                    <label class="admin-field"><span>Titre panneau de pilotage</span><input type="text" name="admin_dashboard_title" value="<?php echo escapeAttribute($adminUi['dashboard_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Description panneau de pilotage</span><textarea name="admin_dashboard_text" rows="2"><?php echo escape($adminUi['dashboard_text'] ?? ''); ?></textarea></label>
                </div>
                <div class="admin-form-actions">
                    <button class="admin-save-button" type="submit">Enregistrer les réglages généraux</button>
                </div>
            </form>
        </section>

        <!-- ── Boutons ──────────────────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'buttons' ? ' is-active' : ''; ?>" data-admin-tab-panel="buttons">
            <form method="post" class="admin-form-card">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="save_buttons">
                <div class="admin-section-heading">
                    <div><h3>Boutons principaux</h3><p class="admin-form-text">Modifie les liens visibles sur la page d\'accueil.</p></div>
                    <button class="admin-inline-tab-link" type="button" data-admin-tab-trigger data-tab="assets">Ajouter une icône</button>
                </div>
                <div class="admin-repeat-grid">
                    <?php for ($i = 0; $i < max(6, count($buttons)); $i++): ?>
                    <?php $btn = $buttons[$i] ?? ['visible' => 0, 'label' => '', 'url' => '', 'type' => 'secondary', 'icon' => '']; ?>
                    <div class="admin-item-card">
                        <div class="admin-item-card-header">
                            <strong>Bouton <?php echo $i + 1; ?></strong>
                            <label class="admin-switch"><input type="checkbox" name="buttons[<?php echo $i; ?>][visible]" value="1" <?php echo ((int)($btn['visible'] ?? 0) === 1) ? 'checked' : ''; ?>><span>Visible</span></label>
                        </div>
                        <label class="admin-field"><span>Libellé</span><input type="text" name="buttons[<?php echo $i; ?>][label]" value="<?php echo escapeAttribute($btn['label'] ?? ''); ?>"></label>
                        <label class="admin-field"><span>URL</span><input type="url" name="buttons[<?php echo $i; ?>][url]" value="<?php echo escapeAttribute($btn['url'] ?? ''); ?>"></label>
                        <label class="admin-field"><span>Style</span>
                            <select name="buttons[<?php echo $i; ?>][type]">
                                <?php foreach ($buttonTypeOptions as $tv => $tl): ?>
                                <option value="<?php echo escapeAttribute($tv); ?>" <?php echo (($btn['type'] ?? 'secondary') === $tv) ? 'selected' : ''; ?>><?php echo escape($tl); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <label class="admin-field"><span>Icône</span>
                            <select name="buttons[<?php echo $i; ?>][icon]">
                                <?php foreach ($iconOptions as $iv => $il): ?>
                                <option value="<?php echo escapeAttribute($iv); ?>" <?php echo (($btn['icon'] ?? '') === $iv) ? 'selected' : ''; ?>><?php echo escape($il); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </div>
                    <?php endfor; ?>
                </div>
                <div class="admin-form-actions"><button class="admin-save-button" type="submit">Enregistrer les boutons</button></div>
            </form>
        </section>


        <!-- ── Liens admin ───────────────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'admin-links' ? ' is-active' : ''; ?>" data-admin-tab-panel="admin-links">
            <form method="post" class="admin-form-card">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="save_admin_links">
                <h3>Boutons réservés aux administrateurs</h3>
                <p class="admin-form-text">Ces liens n\'apparaissent que dans la fenêtre admin après authentification.</p>
                <div class="admin-repeat-grid admin-repeat-grid-compact">
                    <?php for ($i = 0; $i < max(6, count($adminLinks)); $i++): ?>
                    <?php $al = $adminLinks[$i] ?? ['visible' => 0, 'label' => '', 'url' => '']; ?>
                    <div class="admin-item-card">
                        <div class="admin-item-card-header">
                            <strong>Lien admin <?php echo $i + 1; ?></strong>
                            <label class="admin-switch"><input type="checkbox" name="admin_links[<?php echo $i; ?>][visible]" value="1" <?php echo ((int)($al['visible'] ?? 0) === 1) ? 'checked' : ''; ?>><span>Visible</span></label>
                        </div>
                        <label class="admin-field"><span>Libellé</span><input type="text" name="admin_links[<?php echo $i; ?>][label]" value="<?php echo escapeAttribute($al['label'] ?? ''); ?>"></label>
                        <label class="admin-field"><span>URL</span><input type="url" name="admin_links[<?php echo $i; ?>][url]" value="<?php echo escapeAttribute($al['url'] ?? ''); ?>"></label>
                        <label class="admin-switch"><input type="checkbox" name="admin_links[<?php echo $i; ?>][show_in_modal]" value="1" <?php echo ((int)($al['show_in_modal'] ?? 1) === 1) ? 'checked' : ''; ?>><span>Afficher dans la modale</span></label>
                    </div>
                    <?php endfor; ?>
                </div>
                <div class="admin-form-actions"><button class="admin-save-button" type="submit">Enregistrer les liens admin</button></div>
            </form>
        </section>

        <?php require __DIR__ . '/admin-users-panel.php'; ?>

        <!-- ── Maintenance ───────────────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'maintenance' ? ' is-active' : ''; ?>" data-admin-tab-panel="maintenance">
            <form method="post" class="admin-form-card">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="save_maintenance">
                <h3>Mode maintenance</h3>
                <p class="admin-form-text">Active ou désactive la maintenance et modifie les textes affichés aux visiteurs.</p>
                <div class="admin-form-grid">
                    <label class="admin-field admin-field-checkbox admin-field-full"><input type="checkbox" name="maintenance_enabled" value="1" <?php echo ((int)($maintenance['enabled'] ?? 0) === 1) ? 'checked' : ''; ?>><span>Activer le mode maintenance pour les visiteurs</span></label>
                    <label class="admin-field"><span>Titre du bandeau</span><input type="text" name="maintenance_notice_title" value="<?php echo escapeAttribute($maintenance['notice_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Texte du bandeau</span><textarea name="maintenance_notice_text" rows="2"><?php echo escape($maintenance['notice_text'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Badge</span><input type="text" name="maintenance_badge_text" value="<?php echo escapeAttribute($maintenance['badge_text'] ?? ''); ?>"></label>
                    <label class="admin-field"><span>Titre principal</span><input type="text" name="maintenance_title" value="<?php echo escapeAttribute($maintenance['title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Sous-titre</span><textarea name="maintenance_subtitle" rows="2"><?php echo escape($maintenance['subtitle'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Bloc 1 · titre</span><input type="text" name="maintenance_status_title" value="<?php echo escapeAttribute($maintenance['status_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Bloc 1 · texte</span><textarea name="maintenance_status_text" rows="2"><?php echo escape($maintenance['status_text'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Bloc 2 · titre</span><input type="text" name="maintenance_why_title" value="<?php echo escapeAttribute($maintenance['why_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Bloc 2 · texte</span><textarea name="maintenance_why_text" rows="2"><?php echo escape($maintenance['why_text'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Bloc 3 · titre</span><input type="text" name="maintenance_action_title" value="<?php echo escapeAttribute($maintenance['action_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Bloc 3 · texte</span><textarea name="maintenance_action_text" rows="2"><?php echo escape($maintenance['action_text'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Panneau · titre</span><input type="text" name="maintenance_panel_message_title" value="<?php echo escapeAttribute($maintenance['panel_message_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Panneau · texte</span><textarea name="maintenance_panel_message_text" rows="2"><?php echo escape($maintenance['panel_message_text'] ?? ''); ?></textarea></label>
                    <label class="admin-field"><span>Conseils · titre</span><input type="text" name="maintenance_tips_title" value="<?php echo escapeAttribute($maintenance['tips_title'] ?? ''); ?>"></label>
                    <label class="admin-field admin-field-full"><span>Conseils · une ligne par conseil</span><textarea name="maintenance_tips_lines" rows="4"><?php echo escape($maintenanceTipsLinesText); ?></textarea></label>
                    <label class="admin-field admin-field-full"><span>Pied de page</span><input type="text" name="maintenance_footer_note" value="<?php echo escapeAttribute($maintenance['footer_note'] ?? ''); ?>"></label>
                </div>
                <div class="admin-form-actions"><button class="admin-save-button" type="submit">Enregistrer la maintenance</button></div>
            </form>
        </section>

        <!-- ── Mot de passe ──────────────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'password' ? ' is-active' : ''; ?>" data-admin-tab-panel="password">
            <form method="post" class="admin-form-card admin-form-card-password">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="change_password">
                <h3>Mot de passe administrateur</h3>
                <p class="admin-form-text">Le hash est stocké dans <code>web_private/admin_access/admin-password.php</code>.</p>
                <div class="admin-form-grid">
                    <label class="admin-field"><span>Mot de passe actuel</span><input type="password" name="current_password" autocomplete="current-password" required></label>
                    <label class="admin-field"><span>Nouveau mot de passe</span><input type="password" name="new_password" autocomplete="new-password" required></label>
                    <label class="admin-field"><span>Confirmation</span><input type="password" name="confirm_password" autocomplete="new-password" required></label>
                </div>
                <div class="admin-form-actions"><button class="admin-save-button" type="submit">Mettre à jour le mot de passe</button></div>
            </form>
        </section>

        <!-- ── Icônes & images ───────────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'assets' ? ' is-active' : ''; ?>" data-admin-tab-panel="assets">
            <div class="admin-assets-grid admin-assets-grid-top">
                <?php foreach ([['icons', 'Icône', 'assets/icons'], ['images', 'Image', 'assets/images']] as [$target, $label, $hint]): ?>
                <form method="post" class="admin-form-card admin-assets-card" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action"  value="upload_asset">
                    <input type="hidden" name="asset_target"  value="<?php echo $target; ?>">
                    <h3>Ajouter une nouvelle <?php echo strtolower($label); ?></h3>
                    <p class="admin-form-text">Envoie vers <code><?php echo $hint; ?></code>.</p>
                    <div class="admin-form-grid">
                        <div class="admin-field admin-field-full">
                            <span>Fichier image</span>
                            <label class="admin-file-pick">
                                <input type="file" name="asset_file" accept=".png,.jpg,.jpeg,.webp,.gif,.svg,.ico,.avif" required
                                       class="admin-file-input" data-file-input>
                                <span class="admin-file-pick-btn" aria-hidden="true">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                    Choisir un fichier
                                </span>
                                <span class="admin-file-name" data-file-name>Aucun fichier sélectionné</span>
                            </label>
                        </div>
                    </div>
                    <div class="admin-form-actions"><button class="admin-save-button" type="submit">Enregistrer dans <?php echo $hint; ?></button></div>
                </form>
                <?php endforeach; ?>
            </div>
            <div class="admin-assets-grid">
                <?php foreach ([['icons', $iconFiles, 'icons'], ['images', $imageFiles, 'images']] as [$target, $files, $label]): ?>
                <section class="admin-form-card admin-assets-card">
                    <div class="admin-assets-card-header">
                        <div><h3>Fichiers dans <?php echo $label; ?></h3></div>
                        <span class="admin-assets-count"><?php echo count($files); ?> fichier(s)</span>
                    </div>
                    <?php if ($files === []): ?>
                    <p class="admin-form-text">Aucun fichier dans <code>assets/<?php echo $label; ?></code>.</p>
                    <?php else: ?>
                    <ul class="admin-asset-list">
                        <?php foreach ($files as $f): ?>
                        <li class="admin-asset-row">
                            <div class="admin-asset-meta">
                                <a href="<?php echo escape($f['path']); ?>" target="_blank" rel="noopener"><?php echo escape($f['name']); ?></a>
                                <code><?php echo escape($f['path']); ?></code>
                            </div>
                            <form method="post" class="admin-inline-form admin-asset-delete-form">
                                <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
                                <input type="hidden" name="admin_action"  value="delete_asset">
                                <input type="hidden" name="asset_target"  value="<?php echo $target; ?>">
                                <input type="hidden" name="asset_name"    value="<?php echo escapeAttribute($f['name']); ?>">
                                <button class="admin-delete-button" type="submit" onclick="return confirm('Supprimer <?php echo escapeAttribute($f['name']); ?> ?')">Supprimer</button>
                            </form>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </section>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- ── Accès en écriture ──────────────────────────────── -->
        <section class="admin-tab-panel<?php echo $activeAdminTab === 'access' ? ' is-active' : ''; ?>" data-admin-tab-panel="access">
            <div class="admin-form-card">
                <h3>État des accès en écriture</h3>
                <p class="admin-form-text">Vérifie que PHP a bien les droits d\'écriture sur les fichiers et dossiers importants du site.</p>
                <div class="admin-storage-status" style="margin-top:1.25rem">
                    <?php foreach ($storageStatus as $s): ?>
                    <div class="admin-storage-pill<?php echo $s['ok'] ? ' is-ok' : ' is-error'; ?>">
                        <div class="admin-storage-pill-header">
                            <span class="admin-storage-pill-icon" aria-hidden="true"><?php echo $s['ok'] ? '✓' : '✗'; ?></span>
                            <strong><?php echo escape($s['label']); ?></strong>
                            <span class="admin-storage-pill-state"><?php echo escape(describePathState($s['path'])); ?></span>
                        </div>
                        <code class="admin-storage-pill-path"><?php echo escape($s['path']); ?></code>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

    </div><!-- /admin-panel-grid -->
</section>
