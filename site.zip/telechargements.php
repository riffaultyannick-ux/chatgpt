<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Protection site privé
enforcePrivateAccess($isPrivateModeEnabled, $isUserAuthenticated, $isAdminAuthenticated, []);

if ($isAdminAuthenticated && (string)($_GET['admin'] ?? '') === '1') {
    $shouldAutoOpenAdminModal = true;
}
$dlPanelVisible = $isAdminAuthenticated && ((string)($_GET['dl-panel'] ?? '') === '1');
$flash = getFlash();

// Item en édition
$editId   = normalizeText($_GET['edit'] ?? '');
$editItem = null;
if ($isAdminAuthenticated && $editId !== '') {
    foreach ($downloadsPage as $d) {
        if ($d['id'] === $editId) { $editItem = $d; break; }
    }
    $dlPanelVisible = true;
}

// Items publics (visiteurs voient uniquement visible=1)
$publicItems = $isAdminAuthenticated
    ? $downloadsPage
    : array_values(array_filter($downloadsPage, fn($d) => (int)($d['visible'] ?? 0) === 1));

// Catégories disponibles (dans l'ordre d'apparition)
$allCategories = [];
foreach ($publicItems as $d) {
    $cat = $d['category'] ?? '';
    if ($cat !== '' && !in_array($cat, $allCategories, true)) { $allCategories[] = $cat; }
}

// Featured en premier, puis ordre
$featuredItems = array_values(array_filter($publicItems, fn($d) => (int)($d['featured'] ?? 0) === 1));
$regularItems  = array_values(array_filter($publicItems, fn($d) => (int)($d['featured'] ?? 0) === 0));

// Icons for categories
$catIcons = [
    'Windows'    => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801"/></svg>',
    'macOS'      => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/></svg>',
    'Linux'      => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.504 0c-.155 0-.315.008-.48.021C7.27.325 3.593 3.387 2.507 7.464a11.386 11.386 0 0 0-.4 1.777c-.05.308-.075.66-.075.915 0 4.28 2.783 7.99 6.702 9.319.032.014.065.027.1.038a.79.79 0 0 0 .085.028c.22.07.454.126.696.168.262.044.524.071.786.071.54 0 1.076-.086 1.597-.253a.797.797 0 0 0 .085-.036c.018-.008.037-.018.054-.026 3.934-1.383 6.695-5.077 6.695-9.316 0-5.52-4.488-10-10.008-10-3.487 0-6.543 1.782-8.34 4.49-.2.3-.39.61-.56.934C1.58 6.154 1 8.01 1 10c0 6.075 4.925 11 11 11s11-4.925 11-11S18.075 0 12 0c-.166 0-.33.004-.496.012zM7 10c0 .552-.448 1-1 1s-1-.448-1-1 .448-1 1-1 1 .448 1 1zm6 0c0 .552-.448 1-1 1s-1-.448-1-1 .448-1 1-1 1 .448 1 1z"/></svg>',
    'Android'    => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.523 15.341a.57.57 0 0 1-.568-.573.57.57 0 0 1 .568-.573.57.57 0 0 1 .569.573.57.57 0 0 1-.569.573m-11.046 0a.57.57 0 0 1-.569-.573.57.57 0 0 1 .569-.573.57.57 0 0 1 .568.573.57.57 0 0 1-.568.573M17.69 10.6l1.137-1.967a.237.237 0 0 0-.086-.323.237.237 0 0 0-.323.086L17.27 10.38a7.145 7.145 0 0 0-2.86-.594 7.148 7.148 0 0 0-2.861.594L10.41 8.396a.237.237 0 0 0-.323-.086.237.237 0 0 0-.087.323L11.137 10.6C9.26 11.607 7.98 13.567 7.98 15.83h8.04c0-2.263-1.28-4.223-3.157-5.23M6 17.478h12v-1.649H6v1.649z"/></svg>',
    'Android TV' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 7H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h3l-1 2h8l-1-2h3a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zm-8 7H7v-2h4v2zm6 0h-4v-2h4v2z"/></svg>',
    'Apple TV'   => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 7H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h3l-1 2h8l-1-2h3a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zm-8 7H7v-2h4v2zm6 0h-4v-2h4v2z"/></svg>',
    'iOS'        => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>',
];

$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Téléchargez l\'application Emby pour accéder au serveur NéoPcPro depuis votre appareil.">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="Téléchargements – NéoPcPro">
<meta property="og:description" content="Téléchargez l\'application Emby pour votre appareil.">
<meta property="og:site_name"   content="NéoPcPro">
<title>Téléchargements – NéoPcPro</title>
<link rel="stylesheet" href="assets/css/style.css?v=20">
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>

<main class="page"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="<?php echo $shouldAutoOpenAdminModal ? '1' : '0'; ?>">

<!-- ── Zone principale ─────────────────────────────────────────── -->
<section class="hero dl-hero" aria-labelledby="dl-page-title">
<div class="hero-content">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<?php if (isset($_GET['need_login']) && !$isUserAuthenticated && !$isAdminAuthenticated): ?>
<div class="site-flash site-flash-info" role="status">
    <?php echo escape($userConfig['login_message'] ?? 'Vous devez être connecté pour accéder à ce site.'); ?>
    <button type="button" data-user-login-open style="margin-left:1rem;padding:0.4rem 0.9rem;border-radius:8px;border:1px solid rgba(56,189,248,0.35);background:rgba(56,189,248,0.12);color:var(--primary);font-weight:600;cursor:pointer;">
        Se connecter
    </button>
</div>
<?php endif; ?>

<!-- En-tête -->
<div class="dl-page-header">
    <div class="dl-page-header-text">
        <p class="dl-page-eyebrow">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Applications disponibles
        </p>
        <h1 id="dl-page-title" class="dl-page-title">Téléchargements</h1>
        <p class="dl-page-subtitle">Accédez au serveur NéoPcPro depuis n'importe quel appareil. Choisissez votre plateforme et installez l\'application Emby en quelques secondes.</p>
    </div>
    <?php if ($isAdminAuthenticated): ?>
    <a class="news-manage-btn" href="telechargements.php?dl-panel=1#dl-panel">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        Gérer les téléchargements
    </a>
    <?php endif; ?>
</div>

<?php if (empty($publicItems)): ?>
<div class="news-empty">
    <p>Aucun téléchargement disponible pour le moment.</p>
</div>
<?php else: ?>

<!-- Filtres par catégorie -->
<?php if (count($allCategories) > 1): ?>
<div class="dl-filters" role="group" aria-label="Filtrer par plateforme">
    <button class="dl-filter-btn is-active" data-filter="all" type="button">
        <span class="dl-filter-icon" aria-hidden="true">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        </span>
        Toutes les plateformes
    </button>
    <?php foreach ($allCategories as $cat): ?>
    <button class="dl-filter-btn" data-filter="<?php echo escape($cat); ?>" type="button">
        <?php if (isset($catIcons[$cat])): ?>
        <span class="dl-filter-icon" aria-hidden="true"><?php echo $catIcons[$cat]; ?></span>
        <?php endif; ?>
        <?php echo escape($cat); ?>
    </button>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Items mis en avant -->
<?php if (!empty($featuredItems)): ?>
<div class="dl-section">
    <h2 class="dl-section-title">
        <span class="dl-section-icon" aria-hidden="true">⭐</span>
        Recommandé
    </h2>
    <div class="dl-grid dl-grid-featured">
        <?php foreach ($featuredItems as $item): ?>
        <?php include __DIR__ . '/includes/dl-card.php'; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Tous les items par catégorie -->
<?php
$grouped = [];
foreach ($regularItems as $item) {
    $cat = $item['category'] !== '' ? $item['category'] : 'Autres';
    $grouped[$cat][] = $item;
}
?>
<?php if (!empty($grouped)): ?>
<?php foreach ($grouped as $catName => $catItems): ?>
<div class="dl-section" data-category="<?php echo escape($catName); ?>">
    <h2 class="dl-section-title">
        <?php if (isset($catIcons[$catName])): ?>
        <span class="dl-section-cat-icon" aria-hidden="true"><?php echo $catIcons[$catName]; ?></span>
        <?php endif; ?>
        <?php echo escape($catName); ?>
    </h2>
    <div class="dl-grid">
        <?php foreach ($catItems as $item): ?>
        <?php include __DIR__ . '/includes/dl-card.php'; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php endif; /* empty publicItems */ ?>

</div><!-- /hero-content -->
</section><!-- /hero -->

<!-- ── Panneau admin ────────────────────────────────────────── -->
<?php if ($isAdminAuthenticated && $dlPanelVisible): ?>
<section class="admin-panel" id="dl-panel" aria-labelledby="dl-panel-title">
    <div class="admin-panel-header">
        <div>
            <p class="admin-panel-eyebrow">Administration</p>
            <h2 class="admin-panel-title" id="dl-panel-title">Gestion des téléchargements</h2>
            <p class="admin-panel-text">Ajoutez, modifiez et organisez les applications proposées au téléchargement.</p>
        </div>
        <div class="admin-panel-header-actions">
            <a class="admin-utility-link" href="index.php?panel=1#admin-panel">Pilotage du site</a>
            <a class="admin-utility-link" href="telechargements.php">Voir la page</a>
        </div>
    </div>

    <?php if ($flash !== []): ?>
    <div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
        <?php echo escape($flash['message'] ?? ''); ?>
    </div>
    <?php endif; ?>

    <!-- Formulaire ajout / modification -->
    <form method="post" class="admin-form-card">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="save_dl_item">
        <input type="hidden" name="dl_id"        value="<?php echo escapeAttribute($editItem['id'] ?? ''); ?>">

        <h3><?php echo $editItem !== null ? 'Modifier le téléchargement' : 'Ajouter un téléchargement'; ?></h3>
        <?php if ($editItem !== null): ?>
        <p class="admin-form-text">
            Vous modifiez : <strong><?php echo escape($editItem['name']); ?></strong>
            &nbsp;–&nbsp;<a href="telechargements.php?dl-panel=1#dl-panel" style="color:#bae6fd">Annuler</a>
        </p>
        <?php endif; ?>

        <div class="admin-form-grid">
            <label class="admin-field">
                <span>Nom de l\'application <abbr title="obligatoire">*</abbr></span>
                <input type="text" name="dl_name" value="<?php echo escapeAttribute($editItem['name'] ?? ''); ?>" required placeholder="ex : Emby Theater">
            </label>
            <label class="admin-field">
                <span>Catégorie / Plateforme <abbr title="obligatoire">*</abbr></span>
                <input type="text" name="dl_category" value="<?php echo escapeAttribute($editItem['category'] ?? ''); ?>" required placeholder="ex : Windows, Android, iOS…"
                       list="dl-categories-list">
                <datalist id="dl-categories-list">
                    <?php foreach ($allCategories as $cat): ?>
                    <option value="<?php echo escapeAttribute($cat); ?>">
                    <?php endforeach; ?>
                    <option value="Windows"><option value="macOS"><option value="Linux">
                    <option value="Android"><option value="Android TV">
                    <option value="iOS"><option value="Apple TV">
                </datalist>
            </label>
            <label class="admin-field admin-field-full">
                <span>Description</span>
                <textarea name="dl_description" rows="2" placeholder="Ce que fait l\'application, pour qui c\'est adapté…"><?php echo escape($editItem['description'] ?? ''); ?></textarea>
            </label>
            <label class="admin-field">
                <span>URL de téléchargement <abbr title="obligatoire">*</abbr></span>
                <input type="url" name="dl_url" value="<?php echo escapeAttribute($editItem['url'] ?? ''); ?>" required placeholder="https://…">
            </label>
            <label class="admin-field">
                <span>Icône (assets/icons/… ou URL)</span>
                <select name="dl_icon">
                    <?php foreach ($iconOptions as $iv => $il): ?>
                    <option value="<?php echo escapeAttribute($iv); ?>" <?php echo (($editItem['icon'] ?? '') === $iv) ? 'selected' : ''; ?>><?php echo escape($il); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="admin-field">
                <span>Badge (ex : Gratuit, Nouveau, Recommandé)</span>
                <input type="text" name="dl_badge" value="<?php echo escapeAttribute($editItem['badge'] ?? ''); ?>" placeholder="Gratuit">
            </label>
            <label class="admin-field">
                <span>Version (optionnel)</span>
                <input type="text" name="dl_version" value="<?php echo escapeAttribute($editItem['version'] ?? ''); ?>" placeholder="ex : 4.8.0">
            </label>
            <label class="admin-field">
                <span>Ordre d\'affichage (1 = premier)</span>
                <input type="number" name="dl_order" value="<?php echo (int)($editItem['order'] ?? 99); ?>" min="1" max="999">
            </label>
            <label class="admin-field admin-field-checkbox">
                <input type="checkbox" name="dl_visible" value="1" <?php echo ((int)($editItem['visible'] ?? 1) === 1) ? 'checked' : ''; ?>>
                <span>Visible par les visiteurs</span>
            </label>
            <label class="admin-field admin-field-checkbox">
                <input type="checkbox" name="dl_featured" value="1" <?php echo ((int)($editItem['featured'] ?? 0) === 1) ? 'checked' : ''; ?>>
                <span>Mis en avant (section Recommandé)</span>
            </label>
        </div>
        <div class="admin-form-actions">
            <button class="admin-save-button" type="submit">
                <?php echo $editItem !== null ? 'Mettre à jour' : 'Ajouter le téléchargement'; ?>
            </button>
        </div>
    </form>

    <!-- Liste de gestion -->
    <?php if (!empty($downloadsPage)): ?>
    <div class="admin-form-card">
        <h3>Téléchargements existants</h3>
        <p class="admin-form-text"><?php echo count($downloadsPage); ?> entrée(s) au total.</p>

        <ul class="news-manage-list">
        <?php foreach ($downloadsPage as $d): ?>
        <li class="news-manage-row<?php echo (int)($d['visible'] ?? 0) === 0 ? ' is-hidden-row' : ''; ?>">
            <div class="dl-manage-icon-wrap" aria-hidden="true">
                <?php if (!empty($d['icon'])): ?>
                <img src="<?php echo escape($d['icon']); ?>" alt="" width="32" height="32" loading="lazy" style="border-radius:6px;object-fit:contain;background:rgba(255,255,255,.10);padding:3px;">
                <?php endif; ?>
            </div>
            <div class="news-manage-meta">
                <span class="news-manage-title">
                    <?php echo escape($d['name'] ?? '(sans nom)'); ?>
                    <?php if (!empty($d['badge'])): ?><span class="dl-badge dl-badge-sm"><?php echo escape($d['badge']); ?></span><?php endif; ?>
                    <?php if ((int)($d['featured'] ?? 0)): ?><span class="dl-featured-tag">⭐</span><?php endif; ?>
                </span>
                <span class="news-manage-info">
                    <?php echo escape($d['category'] ?? ''); ?>
                    <?php if (!empty($d['version'])): ?> · v<?php echo escape($d['version']); ?><?php endif; ?>
                    <?php if ((int)($d['visible'] ?? 0) === 0): ?> · <em>Masqué</em><?php endif; ?>
                    · Ordre <?php echo (int)($d['order'] ?? 99); ?>
                </span>
            </div>
            <div class="news-manage-actions">
                <a class="news-admin-edit-btn" href="telechargements.php?edit=<?php echo escape($d['id']); ?>&dl-panel=1#dl-panel">Modifier</a>
                <form method="post" class="admin-inline-form">
                    <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action" value="toggle_dl_visible">
                    <input type="hidden" name="dl_id"        value="<?php echo escapeAttribute($d['id']); ?>">
                    <button class="news-admin-toggle-btn" type="submit"><?php echo (int)($d['visible'] ?? 0) === 0 ? 'Publier' : 'Masquer'; ?></button>
                </form>
                <form method="post" class="admin-inline-form">
                    <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action" value="delete_dl_item">
                    <input type="hidden" name="dl_id"        value="<?php echo escapeAttribute($d['id']); ?>">
                    <button class="admin-delete-button" type="submit"
                            style="min-height:36px;font-size:.85rem;padding:.5rem .8rem"
                            onclick="return confirm('Supprimer ce téléchargement ?')">Supprimer</button>
                </form>
            </div>
        </li>
        <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

</section>
<?php endif; ?>

</main>

<!-- ── Modale admin ──────────────────────────────────────────── -->
<div class="admin-modal<?php echo $shouldAutoOpenAdminModal ? ' is-open' : ''; ?>"
     data-admin-modal aria-hidden="<?php echo $shouldAutoOpenAdminModal ? 'false' : 'true'; ?>">
    <div class="admin-modal-backdrop" data-admin-close></div>
    <div class="admin-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="admin-modal-dl-title">
        <button class="admin-modal-close" type="button" aria-label="Fermer" data-admin-close>&#215;</button>
        <div class="admin-modal-content">
            <h2 class="admin-modal-title" id="admin-modal-dl-title"><?php echo escape($adminUi['modal_title'] ?? 'Espace administrateur'); ?></h2>
            <?php if ($isAdminAuthenticated): ?>
            <p class="admin-modal-text">Session admin active.</p>
            <nav class="admin-modal-links" aria-label="Boutons administrateur">
                <?php foreach ($adminLinks as $al): ?>
                <?php if (!isItemVisible($al) || !(int)($al['show_in_modal'] ?? 1)) { continue; } ?>
                <a class="admin-link admin-link-block" href="<?php echo escape($al['url'] ?? '#'); ?>" target="_blank" rel="noopener noreferrer"><?php echo escape($al['label'] ?? ''); ?></a>
                <?php endforeach; ?>
                <a class="admin-link admin-link-block" href="telechargements.php?dl-panel=1#dl-panel">Gérer les téléchargements</a>
            </nav>
            <form method="post" class="admin-logout-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="logout">
                <button class="admin-logout-button" type="submit"><?php echo escape($adminUi['logout_label'] ?? 'Fermer la session admin'); ?></button>
            </form>
            <?php else: ?>
            <p class="admin-modal-text"><?php echo escape($adminUi['help_text'] ?? ''); ?></p>
            <?php if ($isLoginLocked): ?>
            <p class="admin-auth-error" role="alert">Trop de tentatives. Réessayez dans <?php echo $loginLockSecondsRemaining; ?> seconde(s).</p>
            <?php elseif ($adminAuthError !== ''): ?>
            <p class="admin-auth-error" role="alert"><?php echo escape($adminAuthError); ?></p>
            <?php endif; ?>
            <form method="post" class="admin-password-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="login">
                <label class="visually-hidden" for="admin-password-dl">Mot de passe administrateur</label>
                <input class="admin-password-input" id="admin-password-dl" name="admin_password"
                       type="password" autocomplete="current-password"
                       placeholder="<?php echo escapeAttribute($adminUi['password_placeholder'] ?? 'Mot de passe'); ?>"
                       <?php echo $isLoginLocked ? 'disabled' : 'required'; ?>>
                <button class="admin-password-submit" type="submit" <?php echo $isLoginLocked ? 'disabled' : ''; ?>>Ouvrir les boutons admin</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ── Modale description téléchargement ───────────────────────── -->
<div class="dl-modal" id="dl-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="dl-modal-name">
    <div class="dl-modal-backdrop" id="dl-modal-backdrop"></div>
    <div class="dl-modal-dialog">
        <button class="dl-modal-close" type="button" id="dl-modal-close" aria-label="Fermer">&#215;</button>
        <div class="dl-modal-icon-wrap" id="dl-modal-icon-wrap" style="display:none">
            <img class="dl-modal-icon" id="dl-modal-icon" src="" alt="">
        </div>
        <p class="dl-modal-cat" id="dl-modal-cat"></p>
        <h2 class="dl-modal-name" id="dl-modal-name"></h2>
        <p class="dl-modal-desc" id="dl-modal-desc"></p>
        <a class="dl-modal-action" id="dl-modal-action" href="#" target="_blank" rel="noopener noreferrer">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Télécharger
        </a>
    </div>
</div>

<?php
$dlJson = json_encode(array_map(function($d) {
    return [
        'id'          => $d['id'],
        'name'        => $d['name'] ?? '',
        'category'    => $d['category'] ?? '',
        'description' => $d['description'] ?? '',
        'url'         => $d['url'] ?? '#',
        'icon'        => $d['icon'] ?? '',
    ];
}, $publicItems), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<script>var DL_DATA = <?php echo $dlJson; ?>;</script>

<script>
(function(){
/* ── Filtres de catégorie ── */
var filterBtns = document.querySelectorAll('[data-filter]');
var sections   = document.querySelectorAll('.dl-section[data-category]');
if (filterBtns.length) {
    filterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            filterBtns.forEach(function(b){ b.classList.remove('is-active'); });
            btn.classList.add('is-active');
            var filter = btn.getAttribute('data-filter');
            sections.forEach(function(sec) {
                if (filter === 'all' || sec.getAttribute('data-category') === filter) {
                    sec.style.display = '';
                } else {
                    sec.style.display = 'none';
                }
            });
        });
    });
}
})();

(function(){
var modal=document.querySelector('[data-admin-modal]'),opens=document.querySelectorAll('[data-admin-open]'),closes=document.querySelectorAll('[data-admin-close]'),page=document.querySelector('.page'),pwd=document.getElementById('admin-password-dl');
if(!modal||!page||!opens.length)return;
function open(){modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('has-admin-modal-open');if(pwd)setTimeout(function(){pwd.focus();},40);}
function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('has-admin-modal-open');}
opens.forEach(function(b){b.addEventListener('click',open);});
closes.forEach(function(b){b.addEventListener('click',close);});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))close();});
if(page.getAttribute('data-admin-auto-open')==='1')open();
})();
(function(){
var btn=document.querySelector('[data-nav-hamburger]'),menu=document.querySelector('[data-nav-mobile-menu]');
if(!btn||!menu)return;
function toggle(){var open=btn.getAttribute('aria-expanded')==='true';btn.setAttribute('aria-expanded',open?'false':'true');menu.setAttribute('aria-hidden',open?'true':'false');menu.classList.toggle('is-open',!open);}
btn.addEventListener('click',toggle);
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&btn.getAttribute('aria-expanded')==='true')toggle();});
document.addEventListener('click',function(e){if(btn.getAttribute('aria-expanded')==='true'&&!btn.contains(e.target)&&!menu.contains(e.target))toggle();});
})();

(function(){
/* ── Modale description téléchargement ── */
var modal    = document.getElementById('dl-modal');
var backdrop = document.getElementById('dl-modal-backdrop');
var closeBtn = document.getElementById('dl-modal-close');
var iconWrap = document.getElementById('dl-modal-icon-wrap');
var iconEl   = document.getElementById('dl-modal-icon');
var catEl    = document.getElementById('dl-modal-cat');
var nameEl   = document.getElementById('dl-modal-name');
var descEl   = document.getElementById('dl-modal-desc');
var actionEl = document.getElementById('dl-modal-action');
if (!modal) return;

var dlMap = {};
if (typeof DL_DATA !== 'undefined') {
    DL_DATA.forEach(function(d){ dlMap[d.id] = d; });
}
function openDlModal(id) {
    var d = dlMap[id];
    if (!d) return;
    if (d.icon) { iconEl.src = d.icon; iconWrap.style.display = 'flex'; }
    else        { iconWrap.style.display = 'none'; }
    catEl.textContent  = d.category;
    nameEl.textContent = d.name;
    descEl.textContent = d.description;
    actionEl.href      = d.url;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
    closeBtn.focus();
}
function closeDlModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow = '';
}
document.querySelectorAll('[data-open-dl]').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        openDlModal(btn.getAttribute('data-open-dl'));
    });
});
closeBtn.addEventListener('click', closeDlModal);
backdrop.addEventListener('click', closeDlModal);
document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeDlModal(); });
})();
</script>

<!-- ══════════════════════════════════════════════════════════════
     MODALES UTILISATEURS
     ══════════════════════════════════════════════════════════════ -->

<!-- Modale Connexion -->
<div class="user-modal<?php echo isset($_GET['show_login']) ? ' is-open' : ''; ?>" id="login-modal" data-user-modal="login">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Connexion</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['login_message'] ?? 'Connectez-vous pour accéder au site.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="login_user">
            
            <div class="user-field">
                <label for="login_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="login_username" 
                    name="login_username" 
                    placeholder="Votre nom d'utilisateur"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="login_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="login_password" 
                    name="login_password" 
                    placeholder="Votre mot de passe"
                    required
                    autocomplete="current-password"
                >
            </div>
            
            <button type="submit" class="user-submit-btn">Se connecter</button>
        </form>
        
        <?php if ($allowRegistration): ?>
        <div class="user-modal-footer">
            Pas encore de compte ? <button type="button" data-switch-to-register>S'inscrire</button>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modale Inscription -->
<?php if ($allowRegistration): ?>
<div class="user-modal<?php echo isset($_GET['show_register']) ? ' is-open' : ''; ?>" id="register-modal" data-user-modal="register">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Inscription</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['registration_message'] ?? 'Créez un compte pour accéder au contenu.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="register_user">
            
            <div class="user-field">
                <label for="register_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="register_username" 
                    name="register_username" 
                    placeholder="Minimum 3 caractères"
                    minlength="3"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="register_email">Email</label>
                <input 
                    type="email" 
                    id="register_email" 
                    name="register_email" 
                    placeholder="votre@email.com"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="register_password" 
                    name="register_password" 
                    placeholder="Minimum 6 caractères"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password_confirm">Confirmer le mot de passe</label>
                <input 
                    type="password" 
                    id="register_password_confirm" 
                    name="register_password_confirm" 
                    placeholder="Retapez votre mot de passe"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="discovered_from">Comment avez-vous connu ce site ? (optionnel)</label>
                <input 
                    type="text" 
                    id="discovered_from" 
                    name="discovered_from" 
                    placeholder="Google, Discord, un ami..."
                >
            </div>
            
            <button type="submit" class="user-submit-btn">S'inscrire</button>
        </form>
        
        <div class="user-modal-footer">
            Déjà un compte ? <button type="button" data-switch-to-login>Se connecter</button>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
/* ══════════════════════════════════════════════════════════════
   GESTION DES MODALES UTILISATEURS
   ══════════════════════════════════════════════════════════════ */
(function() {
    var loginModal = document.getElementById('login-modal');
    var registerModal = document.getElementById('register-modal');
    
    // Boutons d'ouverture
    var loginOpenBtns = document.querySelectorAll('[data-user-login-open]');
    var registerOpenBtns = document.querySelectorAll('[data-user-register-open]');
    
    // Boutons de fermeture
    var closeBtns = document.querySelectorAll('[data-user-modal-close]');
    
    // Boutons de bascule
    var switchToRegisterBtns = document.querySelectorAll('[data-switch-to-register]');
    var switchToLoginBtns = document.querySelectorAll('[data-switch-to-login]');
    
    // Fonctions d'ouverture/fermeture
    function openModal(modal) {
        if (modal) {
            modal.classList.add('is-open');
            document.body.style.overflow = 'hidden';
        }
    }
    
    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('is-open');
            document.body.style.overflow = '';
        }
    }
    
    function closeAllModals() {
        closeModal(loginModal);
        closeModal(registerModal);
    }
    
    // Ouvrir connexion
    loginOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(loginModal);
        });
    });
    
    // Ouvrir inscription
    registerOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(registerModal);
        });
    });
    
    // Fermer
    closeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var modal = btn.closest('[data-user-modal]');
            closeModal(modal);
        });
    });
    
    // Basculer vers inscription
    switchToRegisterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(loginModal);
            openModal(registerModal);
        });
    });
    
    // Basculer vers connexion
    switchToLoginBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(registerModal);
            openModal(loginModal);
        });
    });
    
    // Fermer au clic sur le backdrop
    [loginModal, registerModal].forEach(function(modal) {
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        }
    });
    
    // Fermer avec Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
})();
</script>

</body>
</html>
