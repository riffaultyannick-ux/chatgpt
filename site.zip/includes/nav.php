<?php
/**
 * NéoPcPro – Barre de navigation responsive
 * Inclure uniquement depuis index.php ou actualites.php.
 */
if (!defined('NEOPCPRO_LOADED')) {
    http_response_code(403);
    exit;
}

$currentPage = basename($_SERVER['PHP_SELF'] ?? 'index.php');
$isIndexPage    = ($currentPage === 'index.php' || $currentPage === '');
$isNewsPage     = ($currentPage === 'actualites.php');
$isDownloadPage = ($currentPage === 'telechargements.php');

$navLinks = [
    ['href' => 'index.php',          'label' => 'Accueil',          'active' => $isIndexPage],
    ['href' => 'actualites.php',     'label' => 'Actualités',       'active' => $isNewsPage],
    ['href' => 'telechargements.php','label' => 'Téléchargements',  'active' => $isDownloadPage],
];

// Badges de navigation
$visibleNewsCount     = count(array_filter($newsArticles,  fn($a) => (int)($a['visible'] ?? 0) === 1));
$visibleDownloadCount = count(array_filter($downloadsPage, fn($d) => (int)($d['visible'] ?? 0) === 1));
?>
<header class="site-nav" id="site-nav" role="banner">
    <div class="nav-inner">

        <!-- Logo -->
        <a class="nav-logo" href="index.php" aria-label="NéoPcPro – Accueil">
            <span class="nav-logo-icon" aria-hidden="true">◈</span>
            <span class="nav-logo-text">NéoPcPro</span>
        </a>

        <!-- Liens de navigation (desktop) -->
        <nav class="nav-links" aria-label="Navigation principale">
            <?php foreach ($navLinks as $link): ?>
            <a
                class="nav-link<?php echo $link['active'] ? ' is-active' : ''; ?>"
                href="<?php echo escape($link['href']); ?>"
                <?php echo $link['active'] ? 'aria-current="page"' : ''; ?>
            >
                <?php echo escape($link['label']); ?>
                <?php if ($link['href'] === 'actualites.php' && $visibleNewsCount > 0): ?>
                <span class="nav-badge"><?php echo $visibleNewsCount; ?></span>
                <?php elseif ($link['href'] === 'telechargements.php' && $visibleDownloadCount > 0): ?>
                <span class="nav-badge"><?php echo $visibleDownloadCount; ?></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </nav>

        <!-- Actions droite -->
        <div class="nav-actions">
            <?php if ($isAdminAuthenticated): ?>
            <span class="nav-admin-indicator" title="Session admin active">
                <span class="nav-admin-dot" aria-hidden="true"></span>
                Admin
            </span>
            <?php endif; ?>
            
            <?php if ($isUserAuthenticated && !$isAdminAuthenticated): ?>
            <!-- Utilisateur connecté -->
            <a href="profil.php" class="nav-user-btn" title="Mon profil">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                </svg>
                <span class="nav-user-name"><?php echo escape($currentUsername); ?></span>
            </a>
            <form method="post" style="display:inline-block;margin:0;">
                <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="logout_user">
                <button type="submit" class="nav-logout-btn" title="Se déconnecter">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                </button>
            </form>
            <?php elseif (!$isAdminAuthenticated): ?>
            <!-- Non connecté : afficher boutons connexion/inscription -->
            <button
                class="nav-login-btn"
                type="button"
                data-user-login-open
                aria-label="Se connecter"
            >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>
                </svg>
                <span>Connexion</span>
            </button>
            <?php if ($allowRegistration): ?>
            <button
                class="nav-register-btn"
                type="button"
                data-user-register-open
                aria-label="S'inscrire"
            >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>
                </svg>
                <span>Inscription</span>
            </button>
            <?php endif; ?>
            <?php endif; ?>
            
            <button
                class="nav-admin-btn<?php echo ($totalPendingNotifications > 0) ? ' has-notification' : ''; ?>"
                type="button"
                data-admin-open
                aria-label="<?php echo escape($adminUi['button_label'] ?? 'Accès administrateur'); ?>"
            >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
                <span class="nav-admin-btn-label"><?php echo escape($adminUi['button_label'] ?? 'Accès admin'); ?></span>
                <?php if ($totalPendingNotifications > 0): ?>
                <span class="notification-badge" aria-label="<?php echo $totalPendingNotifications; ?> notification(s)"><?php echo $totalPendingNotifications; ?></span>
                <?php endif; ?>
            </button>

            <!-- Hamburger (mobile) -->
            <button class="nav-hamburger" type="button" aria-label="Menu" aria-expanded="false" aria-controls="nav-mobile-menu" data-nav-hamburger>
                <span class="hamburger-line" aria-hidden="true"></span>
                <span class="hamburger-line" aria-hidden="true"></span>
                <span class="hamburger-line" aria-hidden="true"></span>
            </button>
        </div>
    </div>

    <!-- Menu mobile -->
    <div class="nav-mobile-menu" id="nav-mobile-menu" aria-hidden="true" data-nav-mobile-menu>
        <nav aria-label="Navigation mobile">
            <?php foreach ($navLinks as $link): ?>
            <a
                class="nav-mobile-link<?php echo $link['active'] ? ' is-active' : ''; ?>"
                href="<?php echo escape($link['href']); ?>"
                <?php echo $link['active'] ? 'aria-current="page"' : ''; ?>
            >
                <?php echo escape($link['label']); ?>
                <?php if ($link['href'] === 'actualites.php' && $visibleNewsCount > 0): ?>
                <span class="nav-badge"><?php echo $visibleNewsCount; ?></span>
                <?php elseif ($link['href'] === 'telechargements.php' && $visibleDownloadCount > 0): ?>
                <span class="nav-badge"><?php echo $visibleDownloadCount; ?></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </nav>
    </div>
</header>
