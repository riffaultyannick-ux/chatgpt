<?php
/**
 * NéoPcPro – Configuration partagée
 * Inclure uniquement depuis index.php ou actualites.php.
 */
if (!defined('NEOPCPRO_LOADED')) {
    http_response_code(403);
    exit;
}

/* ─── Chemins ─────────────────────────────────────────────────────────── */
$rootDir             = dirname(__DIR__);
$privateRoot         = $rootDir . '/web_private';
$dataDir             = $privateRoot . '/data';
$adminCredentialsPath = $privateRoot . '/admin_access/admin-password.php';
$iconsDir            = $rootDir . '/assets/icons';
$imagesDir           = $rootDir . '/assets/images';

/* ─── Valeurs par défaut ──────────────────────────────────────────────── */
$defaultSiteSettings = [
    'site_title'    => 'Bienvenue chez NéoPcPro',
    'site_subtitle' => 'Vous trouverez ici des liens utiles pour accéder à mon serveur multimédia, ainsi qu\'au serveur Discord afin de proposer de nouveaux contenus ou être informé des dernières mises à jour.',
    'og_image'      => '',
    'admin_ui' => [
        'button_label'       => 'Accès administrateur',
        'modal_title'        => 'Espace administrateur',
        'help_text'          => 'Saisissez le mot de passe pour afficher les boutons réservés aux administrateurs et ouvrir le panneau de pilotage.',
        'password_placeholder' => 'Mot de passe administrateur',
        'logout_label'       => 'Fermer la session admin',
        'dashboard_label'    => 'Ouvrir le pilotage du site',
        'dashboard_title'    => 'Pilotage du site',
        'dashboard_text'     => 'Gérez le contenu du site sans toucher au code : page d\'accueil, téléchargements, maintenance, liens d\'administration et mot de passe.',
    ],
    'maintenance' => [
        'enabled'              => 0,
        'notice_title'         => 'Interruption temporaire',
        'notice_text'          => 'Le site NéoPcPro est actuellement inaccessible pour maintenance.',
        'badge_text'           => '⚠️ Site temporairement indisponible',
        'title'                => 'Une intervention technique est en cours',
        'subtitle'             => 'Nous effectuons actuellement une opération de maintenance afin d\'améliorer le service. Merci de réessayer un peu plus tard.',
        'status_title'         => 'État du site',
        'status_text'          => 'L\'accès à cette page et aux services associés est momentanément suspendu pendant l\'intervention.',
        'why_title'            => 'Pourquoi cette page ?',
        'why_text'             => 'Cette indisponibilité temporaire permet d\'appliquer des mises à jour, des correctifs ou des ajustements de configuration en toute sécurité.',
        'action_title'         => 'Que faire ?',
        'action_text'          => 'Aucune action n\'est nécessaire de votre côté. Il suffit de revenir un peu plus tard et de recharger la page.',
        'panel_message_title'  => 'Message affiché aux visiteurs',
        'panel_message_text'   => 'Le site est temporairement inaccessible. Merci de votre compréhension.',
        'tips_title'           => 'Conseils',
        'tips_lines'           => [
            'Fermez simplement cette page puis réessayez ultérieurement.',
            'Actualisez votre navigateur lorsque le service sera rétabli.',
            'Conservez cette page comme page par défaut pendant la maintenance.',
        ],
        'footer_note'          => 'NéoPcPro · Page de maintenance temporaire',
    ],
];

$defaultButtons = [
    ['visible' => 1, 'label' => 'Emby Multimédia',     'url' => 'http://neopcpro.synology.me:8096',          'type' => 'primary',  'icon' => 'assets/icons/emby.png'],
    ['visible' => 1, 'label' => 'Mon serveur Discord', 'url' => 'https://discord.gg/hc7jrDH9Nf',             'type' => 'discord',  'icon' => 'assets/icons/discord.png'],
];


$defaultAdminLinks = [
    ['visible' => 1, 'show_in_modal' => 1, 'label' => 'Administration', 'url' => 'https://neopcpro.synology.me:65001'],
    ['visible' => 1, 'show_in_modal' => 1, 'label' => 'Syncthing',      'url' => 'https://neopcpro.synology.me:8384'],
];

$defaultNews = [];

$defaultNewsCategories = []; // Liste des catégories gérées manuellement

/* ─── Configuration utilisateurs ──────────────────────────────────────── */
require __DIR__ . '/user-functions.php';

$defaultUserConfig = [
    'private_mode_enabled' => 1,
    'allow_registration'   => 1,
    'registration_message' => 'Inscrivez-vous pour accéder au contenu exclusif du serveur NéoPcPro.',
    'login_message'        => 'Connectez-vous pour accéder au site.',
    'require_email_validation' => 0,
    'welcome_message'      => 'Bienvenue sur NéoPcPro ! Votre inscription a été soumise et sera examinée par un administrateur.',
];

$defaultDownloadsPage = [
    [
        'id'          => 'dl-windows-01',
        'visible'     => 1,
        'featured'    => 0,
        'category'    => 'Windows',
        'name'        => 'Emby Theater',
        'description' => 'L\'application Emby officielle pour Windows. Profitez de votre bibliothèque multimédia depuis votre PC ou Home Cinema.',
        'version'     => '',
        'badge'       => 'Gratuit',
        'url'         => 'https://apps.microsoft.com/detail/9nblggh4t70l?cid=emby-website-downloads&mode=full&hl=fr-FR&gl=FR',
        'icon'        => 'assets/icons/windows.png',
        'order'       => 1,
    ],
    [
        'id'          => 'dl-linux-01',
        'visible'     => 1,
        'featured'    => 0,
        'category'    => 'Linux',
        'name'        => 'Emby Theater',
        'description' => 'L\'application Emby officielle pour Linux. Compatible avec les principales distributions.',
        'version'     => '',
        'badge'       => 'Gratuit',
        'url'         => 'https://emby.media/emby-theater-linux.html',
        'icon'        => 'assets/icons/emby.png',
        'order'       => 2,
    ],
    [
        'id'          => 'dl-android-tv-01',
        'visible'     => 1,
        'featured'    => 1,
        'category'    => 'Android TV',
        'name'        => 'Emby pour Android TV',
        'description' => 'L\'expérience Emby optimisée pour votre télévision. Interface grande distance, télécommande et 4K supportés.',
        'version'     => '',
        'badge'       => 'Recommandé',
        'url'         => 'https://play.google.com/store/apps/details?id=tv.emby.embyatv&hl=fr',
        'icon'        => 'assets/icons/android.png',
        'order'       => 3,
    ],
    [
        'id'          => 'dl-android-01',
        'visible'     => 1,
        'featured'    => 0,
        'category'    => 'Android',
        'name'        => 'Emby pour Android',
        'description' => 'Accédez à votre bibliothèque Emby depuis votre smartphone ou tablette Android.',
        'version'     => '',
        'badge'       => 'Gratuit',
        'url'         => 'https://play.google.com/store/apps/details?id=com.mb.android',
        'icon'        => 'assets/icons/android.png',
        'order'       => 4,
    ],
    [
        'id'          => 'dl-appletv-01',
        'visible'     => 1,
        'featured'    => 0,
        'category'    => 'Apple TV',
        'name'        => 'Emby pour Apple TV',
        'description' => 'Interface fluide et optimisée pour votre Apple TV. Navigation intuitive depuis votre canapé.',
        'version'     => '',
        'badge'       => 'Gratuit',
        'url'         => 'https://apps.apple.com/fr/app/emby-for-tv/id1087133526',
        'icon'        => 'assets/icons/apple.png',
        'order'       => 5,
    ],
    [
        'id'          => 'dl-ios-01',
        'visible'     => 1,
        'featured'    => 0,
        'category'    => 'iOS',
        'name'        => 'Emby pour iPhone & iPad',
        'description' => 'Regardez votre bibliothèque Emby en déplacement depuis votre iPhone ou iPad.',
        'version'     => '',
        'badge'       => 'Gratuit',
        'url'         => 'https://apps.apple.com/us/app/emby/id992180193',
        'icon'        => 'assets/icons/apple.png',
        'order'       => 6,
    ],
];

$buttonTypeOptions     = ['primary' => 'Principal', 'secondary' => 'Secondaire', 'discord' => 'Discord', 'ghost' => 'Neutre'];
$defaultIconLabels     = [
    'assets/icons/emby.png'    => 'Emby',
    'assets/icons/discord.png' => 'Discord',
    'assets/icons/windows.png' => 'Windows',
    'assets/icons/android.png' => 'Android',
    'assets/icons/apple.png'   => 'Apple',
    'assets/icons/macos.png'   => 'macOS',
];
$allowedUploadExtensions = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg', 'ico', 'avif'];
$maxUploadSizeBytes      = 8 * 1024 * 1024;
$iconOptions             = ['' => 'Aucune icône'];

/* ─── Fonctions utilitaires ───────────────────────────────────────────── */
function escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function escapeAttribute($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function isItemVisible(array $item): bool
{
    return (int) ($item['visible'] ?? 1) === 1;
}

function redirectToSelf(array $params = [], string $hash = ''): void
{
    $target = strtok($_SERVER['REQUEST_URI'] ?? '/index.php', '?');
    if ($params !== []) {
        $target .= '?' . http_build_query($params);
    }
    if ($hash !== '') {
        $target .= '#' . ltrim($hash, '#');
    }
    header('Location: ' . $target);
    exit;
}

function setFlash(string $type, string $message): void
{
    $_SESSION['site_flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): array
{
    $flash = $_SESSION['site_flash'] ?? [];
    unset($_SESSION['site_flash']);
    return is_array($flash) ? $flash : [];
}

function normalizeText($value): string        { return trim((string) $value); }
function normalizeCheckbox($value): int       { return $value ? 1 : 0; }

function ensureDirectory(string $directory): void
{
    if (!is_dir($directory)) { @mkdir($directory, 0775, true); }
    if (is_dir($directory) && !is_writable($directory)) { @chmod($directory, 0775); }
}

function setWriteError(string $message): void  { $GLOBALS['neopcpro_write_error'] = $message; }
function getWriteError(): string               { return (string) ($GLOBALS['neopcpro_write_error'] ?? ''); }

function describePathState(string $path): string
{
    if (is_dir($path))  { return is_writable($path)  ? 'dossier accessible en écriture'   : 'dossier non accessible en écriture'; }
    if (is_file($path)) { return is_writable($path)  ? 'fichier accessible en écriture'   : 'fichier non accessible en écriture'; }
    $parent = dirname($path);
    if (!is_dir($parent)) { return 'dossier parent introuvable'; }
    return is_writable($parent) ? 'fichier absent mais dossier parent accessible' : 'fichier absent et dossier parent non accessible';
}

function humanizeFileLabel(string $filename): string
{
    $base = pathinfo($filename, PATHINFO_FILENAME);
    $base = trim(preg_replace('/[-_]+/', ' ', $base) ?? $base);
    return $base !== '' ? ucfirst($base) : $filename;
}

function listAssetFiles(string $directory, string $publicPrefix, array $allowedExtensions = []): array
{
    $items = [];
    if (!is_dir($directory)) { return $items; }
    $entries = @scandir($directory);
    if (!is_array($entries)) { return $items; }
    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') { continue; }
        $fullPath = $directory . DIRECTORY_SEPARATOR . $entry;
        if (!is_file($fullPath)) { continue; }
        $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
        if ($allowedExtensions !== [] && !in_array($ext, $allowedExtensions, true)) { continue; }
        $items[] = ['name' => $entry, 'path' => rtrim($publicPrefix, '/') . '/' . $entry, 'mtime' => @filemtime($fullPath) ?: 0];
    }
    usort($items, static fn($a, $b) => strcasecmp($a['name'], $b['name']));
    return $items;
}

function buildIconOptions(string $iconsDir, string $imagesDir, array $labelMap, array $allowedExt): array
{
    $options = ['' => 'Aucune icône'];
    foreach ($labelMap as $path => $label) { $options[$path] = $label; }
    foreach (listAssetFiles($iconsDir, 'assets/icons', $allowedExt) as $f) {
        if (!array_key_exists($f['path'], $options)) { $options[$f['path']] = 'Icône · ' . humanizeFileLabel($f['name']); }
    }
    foreach (listAssetFiles($imagesDir, 'assets/images', $allowedExt) as $f) {
        if (!array_key_exists($f['path'], $options)) { $options[$f['path']] = 'Image · ' . humanizeFileLabel($f['name']); }
    }
    return $options;
}

function sanitizeUploadedFilename(string $filename): string
{
    $base = basename($filename);
    $ext  = strtolower(pathinfo($base, PATHINFO_EXTENSION));
    $name = pathinfo($base, PATHINFO_FILENAME);
    $name = trim(preg_replace('/[^A-Za-z0-9._-]+/', '-', $name) ?? $name, '.-_');
    if ($name === '') { $name = 'fichier'; }
    return $ext !== '' ? $name . '.' . $ext : $name;
}

function moveUploadedAsset(array $file, string $targetDir, string $publicPrefix, array $allowedExt, int $maxBytes): ?array
{
    setWriteError('');
    $code = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($code !== UPLOAD_ERR_OK) {
        $msgs = [UPLOAD_ERR_INI_SIZE => 'Fichier trop volumineux (limite PHP).', UPLOAD_ERR_FORM_SIZE => 'Fichier trop volumineux (limite formulaire).', UPLOAD_ERR_PARTIAL => 'Envoi partiel.', UPLOAD_ERR_NO_FILE => 'Aucun fichier sélectionné.', UPLOAD_ERR_NO_TMP_DIR => 'Dossier temporaire introuvable.', UPLOAD_ERR_CANT_WRITE => 'PHP ne peut pas écrire.', UPLOAD_ERR_EXTENSION => 'Bloqué par une extension PHP.'];
        setWriteError($msgs[$code] ?? 'Échec inconnu.');
        return null;
    }
    ensureDirectory($targetDir);
    if (!is_dir($targetDir) || !is_writable($targetDir)) { setWriteError('Dossier cible inaccessible.'); return null; }
    $safeName = sanitizeUploadedFilename((string) ($file['name'] ?? ''));
    $ext = strtolower(pathinfo($safeName, PATHINFO_EXTENSION));
    if ($ext === '' || !in_array($ext, $allowedExt, true)) { setWriteError('Extension non autorisée. Formats : ' . implode(', ', $allowedExt) . '.'); return null; }
    $tmpName = (string) ($file['tmp_name'] ?? '');
    if ($tmpName === '' || !is_uploaded_file($tmpName)) { setWriteError('Fichier reçu invalide.'); return null; }
    $size = (int) ($file['size'] ?? 0);
    if ($size <= 0) { setWriteError('Fichier vide.'); return null; }
    if ($size > $maxBytes) { setWriteError('Fichier trop volumineux (max ' . round($maxBytes / 1024 / 1024) . ' Mo).'); return null; }
    $candidateName = $safeName;
    $c = 2;
    while (is_file($targetDir . DIRECTORY_SEPARATOR . $candidateName)) {
        $candidateName = pathinfo($safeName, PATHINFO_FILENAME) . '-' . $c++ . '.' . $ext;
    }
    $targetPath = $targetDir . DIRECTORY_SEPARATOR . $candidateName;
    if (!@move_uploaded_file($tmpName, $targetPath)) { setWriteError('Impossible de déplacer le fichier.'); return null; }
    @chmod($targetPath, 0664);
    return ['name' => $candidateName, 'path' => rtrim($publicPrefix, '/') . '/' . $candidateName];
}

function deleteManagedAsset(string $filename, string $targetDir, string $publicPrefix): ?array
{
    setWriteError('');
    $safeName = basename(trim($filename));
    if ($safeName === '' || $safeName !== trim($filename)) { setWriteError('Nom de fichier invalide.'); return null; }
    $targetPath = $targetDir . DIRECTORY_SEPARATOR . $safeName;
    if (!is_file($targetPath)) { setWriteError('Fichier introuvable : ' . $safeName); return null; }
    if (!is_writable($targetPath)) { @chmod($targetPath, 0664); }
    if (!is_writable($targetPath)) { setWriteError('Fichier non accessible en suppression.'); return null; }
    if (!@unlink($targetPath)) { setWriteError('Impossible de supprimer ' . $safeName); return null; }
    return ['name' => $safeName, 'path' => rtrim($publicPrefix, '/') . '/' . $safeName];
}

function removeDeletedAssetReferences(array $rows, string $deletedPath): array
{
    foreach ($rows as &$row) {
        if (is_array($row) && (string) ($row['icon'] ?? '') === $deletedPath) { $row['icon'] = ''; }
    }
    unset($row);
    return $rows;
}

function writeJsonFile(string $path, $data): bool
{
    setWriteError('');
    $directory = dirname($path);
    ensureDirectory($directory);
    if (!is_dir($directory))    { setWriteError('Dossier cible introuvable : ' . $directory); return false; }
    if (!is_writable($directory)) { setWriteError('Dossier non accessible en écriture.'); return false; }
    if (is_file($path) && !is_writable($path)) { @chmod($path, 0664); }
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) { setWriteError('Échec de génération JSON.'); return false; }
    $tmpPath = $path . '.tmp';
    if (@file_put_contents($tmpPath, $json . PHP_EOL, LOCK_EX) === false) { setWriteError('Impossible d\'écrire le fichier temporaire.'); return false; }
    if (!@rename($tmpPath, $path)) { @unlink($tmpPath); setWriteError('Impossible de remplacer le fichier final.'); return false; }
    @chmod($path, 0664);
    return true;
}

function recursiveMerge(array $default, array $data): array
{
    foreach ($data as $key => $value) {
        if (array_key_exists($key, $default) && is_array($default[$key]) && is_array($value)) {
            $default[$key] = recursiveMerge($default[$key], $value);
        } else {
            $default[$key] = $value;
        }
    }
    return $default;
}

function loadJsonFile(string $path, $default)
{
    if (!is_file($path)) { writeJsonFile($path, $default); return $default; }
    $raw = file_get_contents($path);
    if ($raw === false) { return $default; }
    $decoded = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) { return $default; }
    if (is_array($default) && array_is_list($default)) { return $decoded; }
    return recursiveMerge($default, $decoded);
}

function normalizeButtonType(string $type, array $allowed): string
{
    return array_key_exists($type, $allowed) ? $type : 'secondary';
}

function normalizeIcon(string $icon, array $allowed): string
{
    return array_key_exists($icon, $allowed) ? $icon : '';
}

function normalizeListItems(array $rows, array $options = []): array
{
    $opts = array_merge(['allowedTypes' => [], 'allowedIcons' => [], 'supportsType' => false, 'supportsIcon' => false, 'minimumRows' => 0, 'extraFields' => []], $options);
    $items = [];
    foreach ($rows as $row) {
        if (!is_array($row)) { continue; }
        $item = ['visible' => normalizeCheckbox($row['visible'] ?? ''), 'label' => normalizeText($row['label'] ?? ''), 'url' => normalizeText($row['url'] ?? '')];
        if ($opts['supportsType'])  { $item['type'] = normalizeButtonType((string) ($row['type'] ?? 'secondary'), $opts['allowedTypes']); }
        if ($opts['supportsIcon'])  { $item['icon'] = normalizeIcon((string) ($row['icon'] ?? ''), $opts['allowedIcons']); }
        foreach ($opts['extraFields'] ?? [] as $field) {
            $item[$field] = normalizeCheckbox($row[$field] ?? '');
        }
        if ($item['label'] !== '' || $item['url'] !== '') { $items[] = $item; }
    }
    while (count($items) < (int) $opts['minimumRows']) {
        $item = ['visible' => 0, 'label' => '', 'url' => ''];
        if ($opts['supportsType'])  { $item['type'] = 'secondary'; }
        if ($opts['supportsIcon'])  { $item['icon'] = ''; }
        foreach ($opts['extraFields'] ?? [] as $field) { $item[$field] = 0; }
        $items[] = $item;
    }
    return $items;
}

function buildCsrfToken(): string
{
    if (empty($_SESSION['site_csrf_token'])) { $_SESSION['site_csrf_token'] = bin2hex(random_bytes(32)); }
    return (string) $_SESSION['site_csrf_token'];
}

function verifyCsrfToken(string $token): bool
{
    return hash_equals((string) ($_SESSION['site_csrf_token'] ?? ''), $token);
}

function writeAdminPasswordFile(string $path, string $hash): bool
{
    setWriteError('');
    $content  = "<?php\n/**\n * Mot de passe administrateur NéoPcPro.\n * Ce fichier est chargé automatiquement.\n */\n";
    $content .= '$adminAccessPasswordHash = ' . var_export($hash, true) . ";\n";
    $directory = dirname($path);
    ensureDirectory($directory);
    if (!is_dir($directory) || !is_writable($directory)) { setWriteError('Dossier du mot de passe inaccessible.'); return false; }
    if (is_file($path) && !is_writable($path)) { @chmod($path, 0664); }
    $tmpPath = $path . '.tmp';
    if (@file_put_contents($tmpPath, $content, LOCK_EX) === false) { setWriteError('Impossible d\'écrire le fichier temporaire.'); return false; }
    if (!@rename($tmpPath, $path)) { @unlink($tmpPath); setWriteError('Impossible de remplacer le fichier.'); return false; }
    @chmod($path, 0664);
    return true;
}

/* Génère un identifiant unique court pour les articles */
function generateNewsId(): string
{
    return substr(bin2hex(random_bytes(8)), 0, 12);
}

function normalizeNewsArticles(array $rows): array
{
    $articles = [];
    foreach ($rows as $row) {
        if (!is_array($row)) { continue; }
        $articles[] = [
            'id'       => normalizeText($row['id'] ?? generateNewsId()),
            'visible'  => normalizeCheckbox($row['visible'] ?? 1),
            'pinned'   => normalizeCheckbox($row['pinned'] ?? 0),
            'category' => normalizeText($row['category'] ?? ''),
            'title'    => normalizeText($row['title'] ?? ''),
            'summary'  => normalizeText($row['summary'] ?? ''),
            'content'  => normalizeText($row['content'] ?? ''),
            'date'     => normalizeText($row['date'] ?? date('Y-m-d')),
            'image'    => normalizeText($row['image'] ?? ''),
            'video'    => normalizeText($row['video'] ?? ''),
        ];
    }
    return $articles;
}

function normalizeDownloadsPage(array $rows): array
{
    $items = [];
    foreach ($rows as $row) {
        if (!is_array($row)) { continue; }
        $items[] = [
            'id'          => normalizeText($row['id']          ?? generateNewsId()),
            'visible'     => normalizeCheckbox($row['visible']  ?? 1),
            'featured'    => normalizeCheckbox($row['featured'] ?? 0),
            'category'    => normalizeText($row['category']     ?? ''),
            'name'        => normalizeText($row['name']         ?? ''),
            'description' => normalizeText($row['description']  ?? ''),
            'version'     => normalizeText($row['version']      ?? ''),
            'badge'       => normalizeText($row['badge']        ?? ''),
            'url'         => normalizeText($row['url']          ?? ''),
            'icon'        => normalizeText($row['icon']         ?? ''),
            'order'       => (int) ($row['order']              ?? 99),
        ];
    }
    usort($items, fn($a, $b) => $a['order'] <=> $b['order']);
    return $items;
}

/* ─── Session ─────────────────────────────────────────────────────────── */
if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'domain' => '',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true, 'samesite' => 'Lax',
    ]);
}
session_name('neopcpro_admin');
session_start();

/* ─── Limitation des tentatives de connexion ─────────────────────────── */
$loginAttempts            = (int) ($_SESSION['login_attempts'] ?? 0);
$loginLockedUntil         = (int) ($_SESSION['login_locked_until'] ?? 0);
$isLoginLocked            = $loginLockedUntil > time();
$loginLockSecondsRemaining = $isLoginLocked ? ($loginLockedUntil - time()) : 0;

/* ─── CSRF ────────────────────────────────────────────────────────────── */
$csrfToken = buildCsrfToken();

/* ─── Initialisation des répertoires ─────────────────────────────────── */
ensureDirectory($dataDir);
ensureDirectory($iconsDir);
ensureDirectory($imagesDir);

$iconOptions = buildIconOptions($iconsDir, $imagesDir, $defaultIconLabels, $allowedUploadExtensions);

/* ─── Chargement des données ──────────────────────────────────────────── */
$siteSettings = loadJsonFile($dataDir . '/site-settings.json', $defaultSiteSettings);
$buttons      = loadJsonFile($dataDir . '/main-buttons.json',  $defaultButtons);

$adminLinks   = loadJsonFile($dataDir . '/admin-links.json', $defaultAdminLinks);
$newsArticles     = normalizeNewsArticles(loadJsonFile($dataDir . '/news.json', $defaultNews));
$newsCategories   = array_values(array_filter(
    (array) loadJsonFile($dataDir . '/news-categories.json', $defaultNewsCategories),
    fn($c) => is_string($c) && trim($c) !== ''
));
$downloadsPage = normalizeDownloadsPage(loadJsonFile($dataDir . '/downloads-page.json', $defaultDownloadsPage));

/* ─── Chargement des données utilisateurs ─────────────────────────────── */
$userConfig      = loadJsonFile($dataDir . '/user-config.json', $defaultUserConfig);
$users           = normalizeUsers(loadJsonFile($dataDir . '/users.json', $defaultUsers));
$loginHistory    = normalizeLoginHistory(loadJsonFile($dataDir . '/user-login-history.json', $defaultLoginHistory));
$comments        = normalizeComments(loadJsonFile($dataDir . '/comments.json', $defaultComments));

$usersPath        = $dataDir . '/users.json';
$loginHistoryPath = $dataDir . '/user-login-history.json';
$commentsPath     = $dataDir . '/comments.json';
$userConfigPath   = $dataDir . '/user-config.json';

/* ─── Variables dérivées utilisateurs ────────────────────────────────── */
$isPrivateModeEnabled  = (int)($userConfig['private_mode_enabled'] ?? 1) === 1;
$allowRegistration     = (int)($userConfig['allow_registration'] ?? 1) === 1;
$pendingUsersCount     = countPendingUsers($users);
$pendingCommentsCount  = countPendingComments($comments);
$totalPendingNotifications = $pendingUsersCount + $pendingCommentsCount;

/* ─── Mot de passe admin ──────────────────────────────────────────────── */
if (is_file($adminCredentialsPath)) { require $adminCredentialsPath; }
$adminAccessPasswordHash = isset($adminAccessPasswordHash) ? (string) $adminAccessPasswordHash : '';

/* ─── État d'authentification ─────────────────────────────────────────── */
$adminSessionKey         = 'neopcpro_admin_authenticated';
$adminAuthError          = '';
$shouldAutoOpenAdminModal = false;
$adminPanelVisible       = false;
$requestMethod           = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$isAdminAuthenticated    = !empty($_SESSION[$adminSessionKey]);
$maintenanceEnabled      = (int) ($siteSettings['maintenance']['enabled'] ?? 0) === 1;

/* ─── État d'authentification utilisateur ─────────────────────────────── */
$isUserAuthenticated = isUserAuthenticated();
$currentUserId       = getCurrentUserId();
$currentUsername     = getCurrentUsername();
$currentUser         = $currentUserId ? findUserById($currentUserId, $users) : null;

// Vérifier que l'utilisateur n'est pas banni
if ($isUserAuthenticated && $currentUser && $currentUser['status'] === 'banned') {
    logoutUser();
    $isUserAuthenticated = false;
    $currentUserId = null;
    $currentUsername = null;
    $currentUser = null;
    setFlash('danger', 'Votre compte a été banni.');
}

/* ─── Variables dérivées ──────────────────────────────────────────────── */
$adminUi       = $siteSettings['admin_ui']      ?? [];
$maintenance   = $siteSettings['maintenance']   ?? [];

$iconFiles  = listAssetFiles($iconsDir,  'assets/icons',  $allowedUploadExtensions);
$imageFiles = listAssetFiles($imagesDir, 'assets/images', $allowedUploadExtensions);

$storageStatus = [
    ['label' => 'Dossier de données',  'path' => $dataDir,                                'ok' => is_dir($dataDir) && is_writable($dataDir)],
    ['label' => 'Réglages du site',    'path' => $dataDir . '/site-settings.json',        'ok' => (!is_file($dataDir . '/site-settings.json') && is_writable($dataDir)) || (is_file($dataDir . '/site-settings.json') && is_writable($dataDir . '/site-settings.json'))],
    ['label' => 'Mot de passe admin',  'path' => $adminCredentialsPath,                   'ok' => (!is_file($adminCredentialsPath) && is_writable(dirname($adminCredentialsPath))) || (is_file($adminCredentialsPath) && is_writable($adminCredentialsPath))],
    ['label' => 'Dossier icons',       'path' => $iconsDir,                               'ok' => is_dir($iconsDir) && is_writable($iconsDir)],
    ['label' => 'Dossier images',      'path' => $imagesDir,                              'ok' => is_dir($imagesDir) && is_writable($imagesDir)],
    ['label' => 'Actualités',          'path' => $dataDir . '/news.json',                 'ok' => (!is_file($dataDir . '/news.json') && is_writable($dataDir)) || (is_file($dataDir . '/news.json') && is_writable($dataDir . '/news.json'))],
    ['label' => 'Catégories actus',    'path' => $dataDir . '/news-categories.json',      'ok' => (!is_file($dataDir . '/news-categories.json') && is_writable($dataDir)) || (is_file($dataDir . '/news-categories.json') && is_writable($dataDir . '/news-categories.json'))],
    ['label' => 'Téléchargements page',  'path' => $dataDir . '/downloads-page.json',       'ok' => (!is_file($dataDir . '/downloads-page.json') && is_writable($dataDir)) || (is_file($dataDir . '/downloads-page.json') && is_writable($dataDir . '/downloads-page.json'))],
    ['label' => 'Utilisateurs',          'path' => $dataDir . '/users.json',                'ok' => (!is_file($dataDir . '/users.json') && is_writable($dataDir)) || (is_file($dataDir . '/users.json') && is_writable($dataDir . '/users.json'))],
    ['label' => 'Historique connexions', 'path' => $dataDir . '/user-login-history.json',  'ok' => (!is_file($dataDir . '/user-login-history.json') && is_writable($dataDir)) || (is_file($dataDir . '/user-login-history.json') && is_writable($dataDir . '/user-login-history.json'))],
    ['label' => 'Commentaires',          'path' => $dataDir . '/comments.json',             'ok' => (!is_file($dataDir . '/comments.json') && is_writable($dataDir)) || (is_file($dataDir . '/comments.json') && is_writable($dataDir . '/comments.json'))],
    ['label' => 'Config utilisateurs',   'path' => $dataDir . '/user-config.json',          'ok' => (!is_file($dataDir . '/user-config.json') && is_writable($dataDir)) || (is_file($dataDir . '/user-config.json') && is_writable($dataDir . '/user-config.json'))],
];

$maintenanceTipsLinesText = implode(PHP_EOL, array_map('strval', $maintenance['tips_lines'] ?? []));
