<?php
/**
 * NéoPcPro – Carte de téléchargement
 * Inclure depuis telechargements.php uniquement.
 * Attend $item (tableau) dans le scope appelant.
 */
if (!defined('NEOPCPRO_LOADED')) { http_response_code(403); exit; }

$isHiddenItem  = (int)($item['visible'] ?? 0) === 0;
$isFeatured    = (int)($item['featured'] ?? 0) === 1;
$hasBadge      = trim($item['badge'] ?? '') !== '';
$hasVersion    = trim($item['version'] ?? '') !== '';
$hasDesc       = trim($item['description'] ?? '') !== '';
?>
<div class="dl-card<?php echo $isHiddenItem ? ' is-hidden-item' : ''; ?><?php echo $isFeatured ? ' is-featured' : ''; ?>"
     data-category="<?php echo escape($item['category'] ?? ''); ?>"
     data-dl-card>

    <!-- Badges admin (visibles admin seulement) -->
    <?php if ($isHiddenItem && $isAdminAuthenticated): ?>
    <span class="dl-admin-badge dl-admin-badge-hidden">🙈 Masqué</span>
    <?php endif; ?>
    <?php if ($isFeatured): ?>
    <span class="dl-admin-badge dl-admin-badge-featured">⭐ Recommandé</span>
    <?php endif; ?>

    <div class="dl-card-inner">
        <!-- Icône -->
        <div class="dl-card-icon-wrap" aria-hidden="true">
            <?php if (!empty($item['icon'])): ?>
            <img class="dl-card-icon" src="<?php echo escape($item['icon']); ?>" alt="" loading="lazy" width="40" height="40">
            <?php else: ?>
            <div class="dl-card-icon-placeholder">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            </div>
            <?php endif; ?>
        </div>

        <!-- Contenu -->
        <div class="dl-card-body">
            <div class="dl-card-meta">
                <?php if (!empty($item['category'])): ?>
                <span class="dl-card-category"><?php echo escape($item['category']); ?></span>
                <?php endif; ?>
                <?php if ($hasBadge): ?>
                <span class="dl-badge"><?php echo escape($item['badge']); ?></span>
                <?php endif; ?>
                <?php if ($hasVersion): ?>
                <span class="dl-version">v<?php echo escape($item['version']); ?></span>
                <?php endif; ?>
            </div>

            <h3 class="dl-card-name"><?php echo escape($item['name'] ?? ''); ?></h3>

            <?php if ($hasDesc): ?>
            <p class="dl-card-desc"><?php echo escape($item['description']); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bouton → ouvre modale description -->
    <?php if ($hasDesc): ?>
    <button class="dl-card-expand-hint"
            type="button"
            data-open-dl="<?php echo escapeAttribute($item['id']); ?>"
            aria-label="Voir la description complète de <?php echo escapeAttribute($item['name'] ?? ''); ?>">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="5 12 12 5 19 12"/><polyline points="5 19 12 12 19 19"/></svg>
        Voir la description complète
    </button>
    <?php endif; ?>

    <!-- Bouton de téléchargement -->
    <div class="dl-card-footer">
        <a class="dl-download-btn"
           href="<?php echo escape($item['url'] ?? '#'); ?>"
           target="_blank" rel="noopener noreferrer"
           aria-label="Télécharger <?php echo escapeAttribute($item['name'] ?? ''); ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Télécharger
        </a>

        <?php if ($isAdminAuthenticated): ?>
        <div class="dl-card-admin-actions">
            <a class="news-admin-edit-btn"
               href="telechargements.php?edit=<?php echo escape($item['id']); ?>&dl-panel=1#dl-panel">Modifier</a>
            <form method="post" class="admin-inline-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="toggle_dl_visible">
                <input type="hidden" name="dl_id"        value="<?php echo escapeAttribute($item['id']); ?>">
                <button class="news-admin-toggle-btn" type="submit">
                    <?php echo $isHiddenItem ? 'Publier' : 'Masquer'; ?>
                </button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>
