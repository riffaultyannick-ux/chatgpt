<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Protection site privé
enforcePrivateAccess($isPrivateModeEnabled, $isUserAuthenticated, $isAdminAuthenticated, []);

if ($isAdminAuthenticated && (string)($_GET['admin'] ?? '') === '1') {
    $shouldAutoOpenAdminModal = true;
}
$newsPanelVisible = $isAdminAuthenticated && ((string)($_GET['news-panel'] ?? '') === '1');
$flash = getFlash();

// Article en édition
$editId      = normalizeText($_GET['edit'] ?? '');
$editArticle = null;
if ($isAdminAuthenticated && $editId !== '') {
    foreach ($newsArticles as $a) {
        if ($a['id'] === $editId) { $editArticle = $a; break; }
    }
    $newsPanelVisible = true;
}

// Tri : épinglés d'abord, puis par date décroissante
// Tri : date décroissante (épinglés en tête au sein de chaque catégorie)
usort($newsArticles, function($a, $b) {
    $da = $a['date'] ?? '0000-00-00';
    $db = $b['date'] ?? '0000-00-00';
    return strcmp($db, $da);
});

$publicArticles = $isAdminAuthenticated
    ? $newsArticles
    : array_values(array_filter($newsArticles, fn($a) => (int)($a['visible'] ?? 0) === 1));

// Groupement par catégorie, triées par nombre d'articles décroissant
$categorized = [];
foreach ($publicArticles as $article) {
    $cat = trim($article['category'] ?? '');
    $key = $cat !== '' ? $cat : '__none__';
    $categorized[$key][] = $article;
}
// Sort: categories with most articles first; "no category" always last
uksort($categorized, function($a, $b) use ($categorized) {
    if ($a === '__none__') return 1;
    if ($b === '__none__') return -1;
    return count($categorized[$b]) - count($categorized[$a]);
});
// Collect all existing categories for the datalist
$existingCategories = array_filter(array_keys($categorized), fn($k) => $k !== '__none__');

$ogTitle = 'Actualités – NéoPcPro';
$ogDesc  = escape('Les dernières nouvelles du serveur NéoPcPro.');
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $ogDesc; ?>">
<meta name="robots" content="index, follow">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="<?php echo escape($ogTitle); ?>">
<meta property="og:description" content="<?php echo $ogDesc; ?>">
<meta property="og:site_name"   content="NéoPcPro">
<title>Actualités – NéoPcPro</title>
<link rel="stylesheet" href="assets/css/style.css?v=20">
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>

<main class="page"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="<?php echo $shouldAutoOpenAdminModal ? '1' : '0'; ?>">

<!-- ── En-tête de page ────────────────────────────────────────── -->
<section class="hero" aria-labelledby="news-page-title">
<div class="hero-content">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<?php if (isset($_GET['need_login']) && !$isUserAuthenticated && !$isAdminAuthenticated): ?>
<div class="site-flash site-flash-info" role="status">
    <?php echo escape($userConfig['login_message'] ?? 'Vous devez être connecté pour accéder à ce site.'); ?>
    <button type="button" data-user-login-open style="margin-left:1rem;padding:0.4rem 0.9rem;border-radius:8px;border:1px solid rgba(56,189,248,0.35);background:rgba(56,189,248,0.12);color:var(--primary);font-weight:600;cursor:pointer;">
        Se connecter
    </button>
</div>
<?php endif; ?>

<div class="news-page-header">
    <div>
        <h1 id="news-page-title" class="news-page-title">Actualités</h1>
        <p class="subtitle">Les dernières nouvelles du serveur NéoPcPro.</p>
    </div>
    <?php if ($isAdminAuthenticated): ?>
    <a class="news-manage-btn" href="actualites.php?news-panel=1#news-panel">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        Gérer les actualités
    </a>
    <?php endif; ?>
</div>

<!-- ── Liste des articles ─────────────────────────────────────── -->
<?php if (empty($publicArticles)): ?>
<div class="news-empty">
    <p>Aucune actualité pour le moment. Revenez bientôt !</p>
</div>
<?php else: ?>
<?php foreach ($categorized as $catKey => $catArticles): ?>
<?php $catLabel = $catKey === '__none__' ? 'Autres' : $catKey; ?>
<?php $catId = 'cat-' . preg_replace('/[^a-z0-9]+/', '-', strtolower($catLabel)); ?>
<div class="news-category-section<?php echo $catKey === '__none__' ? ' is-uncategorized' : ''; ?>"
     data-cat-section>

    <!-- En-tête cliquable → accordéon -->
    <button class="news-category-header"
            type="button"
            data-cat-toggle
            aria-expanded="false"
            aria-controls="<?php echo $catId; ?>">
        <div class="news-category-icon" aria-hidden="true">
            <?php echo $catKey === '__none__' ? '📋' : '📁'; ?>
        </div>
        <h2 class="news-category-title"><?php echo escape($catLabel); ?></h2>
        <span class="news-category-count"><?php echo count($catArticles); ?> article<?php echo count($catArticles) > 1 ? 's' : ''; ?></span>
        <span class="news-category-arrow" aria-hidden="true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
        </span>
    </button>

    <!-- Grille des articles (accordéon) -->
    <div class="news-category-body" id="<?php echo $catId; ?>" aria-hidden="true">
        <div class="news-category-grid">
<?php foreach ($catArticles as $article): ?>
<?php $isHidden = (int)($article['visible'] ?? 0) === 0; ?>
<?php $hasContent = !empty(trim($article['content'] ?? '')); ?>
<article class="news-card<?php echo $isHidden ? ' is-hidden-article' : ''; ?><?php echo (int)($article['pinned'] ?? 0) ? ' is-pinned' : ''; ?>"
         data-news-card>

    <!-- Thumbnail -->
    <div class="news-card-thumb">
        <?php if (!empty($article['image'])): ?>
        <img class="news-card-img" src="<?php echo escape($article['image']); ?>" alt="" loading="lazy">
        <?php else: ?>
        <div class="news-card-no-img" aria-hidden="true">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
        </div>
        <?php endif; ?>
    </div>

    <!-- En-tête de carte -->
    <div class="news-card-header">
        <div class="news-card-meta-row">
            <time class="news-card-date" datetime="<?php echo escape($article['date'] ?? ''); ?>">
                <?php $ts = strtotime($article['date'] ?? ''); echo $ts ? date('j F Y', $ts) : escape($article['date'] ?? ''); ?>
            </time>
            <?php if ((int)($article['pinned'] ?? 0)): ?>
            <span class="news-pinned-badge">📌 Épinglé</span>
            <?php endif; ?>
            <?php if ($isHidden): ?>
            <span class="dl-admin-badge dl-admin-badge-hidden">🙈 Masqué</span>
            <?php endif; ?>
        </div>
        <h2 class="news-card-title"><?php echo escape($article['title'] ?? ''); ?></h2>
    </div>

    <!-- Résumé -->
    <?php if (!empty($article['summary'])): ?>
    <p class="news-card-summary"><?php echo escape($article['summary']); ?></p>
    <?php endif; ?>

    <!-- Bouton Lire la suite → modale -->
    <?php if ($hasContent || !empty($article['summary'])): ?>
    <button class="news-card-toggle"
            type="button"
            data-open-article="<?php echo escapeAttribute($article['id']); ?>"
            aria-label="Lire l'article : <?php echo escapeAttribute($article['title'] ?? ''); ?>">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="5 12 12 5 19 12"/><polyline points="5 19 12 12 19 19"/></svg>
        Lire la suite
    </button>
    <?php endif; ?>

    <!-- Boutons admin -->
    <?php if ($isAdminAuthenticated): ?>
    <div class="news-card-admin-bar">
        <a class="news-admin-edit-btn" href="actualites.php?edit=<?php echo escape($article['id']); ?>&news-panel=1#news-panel">Modifier</a>
        <form method="post" class="admin-inline-form">
            <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action"  value="toggle_news_visible">
            <input type="hidden" name="news_id"       value="<?php echo escapeAttribute($article['id']); ?>">
            <button class="news-admin-toggle-btn" type="submit"><?php echo $isHidden ? 'Publier' : 'Masquer'; ?></button>
        </form>
        <form method="post" class="admin-inline-form">
            <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action"  value="delete_news_article">
            <input type="hidden" name="news_id"       value="<?php echo escapeAttribute($article['id']); ?>">
            <button class="news-admin-delete-btn admin-delete-button" type="submit"
                    onclick="return confirm('Supprimer cet article ?')" style="min-height:34px;font-size:.82rem;padding:.4rem .7rem">Supprimer</button>
        </form>
    </div>
    <?php endif; ?>
</article>
<?php endforeach; ?>
        </div><!-- /news-category-grid -->
    </div><!-- /news-category-body -->
</div><!-- /news-category-section -->
<?php endforeach; ?>
<?php endif; ?>

<!-- ── Modale article ─────────────────────────────────────────── -->
<div class="article-modal" id="article-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="article-modal-title">
    <div class="article-modal-backdrop" id="article-modal-backdrop"></div>
    <div class="article-modal-dialog">
        <button class="article-modal-close" type="button" id="article-modal-close" aria-label="Fermer">&#215;</button>
        <img class="article-modal-img" id="article-modal-img" src="" alt="" style="display:none">
        <div class="article-modal-header">
            <div class="article-modal-meta">
                <span class="article-modal-date" id="article-modal-date"></span>
                <span id="article-modal-pinned" style="display:none" class="news-pinned-badge">📌 Épinglé</span>
            </div>
            <h2 class="article-modal-title" id="article-modal-title"></h2>
        </div>
        <div class="article-modal-body">
            <p class="article-modal-summary" id="article-modal-summary" style="display:none"></p>
            <div class="article-modal-video-wrap" id="article-modal-video-wrap" style="display:none">
                <!-- iframe pour YouTube/Vimeo, injecté par JS -->
            </div>
            <div class="article-modal-content" id="article-modal-content"></div>
            
            <!-- Section Commentaires -->
            <div class="article-comments-section" id="article-modal-comments">
                <!-- Formulaire ajout commentaire (si utilisateur connecté) -->
                <?php if ($isUserAuthenticated): ?>
                <div class="comment-form-wrapper">
                    <h3 class="comments-title">Ajouter un commentaire</h3>
                    <form method="POST" class="comment-add-form" id="comment-add-form">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="add_comment">
                        <input type="hidden" name="article_id" id="comment-article-id" value="">
                        
                        <textarea 
                            name="comment_content" 
                            placeholder="Votre commentaire..." 
                            maxlength="2000" 
                            required
                            rows="4"
                        ></textarea>
                        <div class="comment-form-footer">
                            <small>Maximum 2000 caractères. Votre commentaire sera modéré avant publication.</small>
                            <button type="submit" class="comment-submit-btn">Publier</button>
                        </div>
                    </form>
                </div>
                <?php elseif (!$isAdminAuthenticated): ?>
                <div class="comment-login-prompt">
                    <p>Connectez-vous pour commenter.</p>
                    <button type="button" data-user-login-open class="comment-login-btn">Se connecter</button>
                </div>
                <?php endif; ?>
                
                <!-- Liste des commentaires -->
                <div class="comments-list-wrapper">
                    <h3 class="comments-title">Commentaires <span id="comments-count">0</span></h3>
                    <div id="comments-list"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Données JSON pour le JS de la modale
$articlesJson = json_encode(array_map(function($a) use ($comments, $isAdminAuthenticated) {
    $ts = @strtotime($a['date'] ?? '');
    
    // Récupérer les commentaires pour cet article
    $articleComments = getCommentsForArticle($a['id'], $comments, $isAdminAuthenticated);
    $commentsData = array_map(function($c) {
        return [
            'id'         => $c['id'],
            'username'   => $c['username'],
            'content'    => $c['content'],
            'status'     => $c['status'],
            'created_at' => $c['created_at'],
        ];
    }, $articleComments);
    
    return [
        'id'       => $a['id'],
        'title'    => $a['title'] ?? '',
        'category' => $a['category'] ?? '',
        'date'     => $ts ? date('j F Y', $ts) : ($a['date'] ?? ''),
        'summary'  => $a['summary'] ?? '',
        'content'  => $a['content'] ?? '',
        'image'    => $a['image'] ?? '',
        'video'    => $a['video'] ?? '',
        'pinned'   => (int)($a['pinned'] ?? 0),
        'comments' => $commentsData,
    ];
}, $publicArticles), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<script>var ARTICLES_DATA = <?php echo $articlesJson; ?>;</script>

</div>
</section>

<!-- ── Panneau de gestion des actualités (admin) ─────────────── -->
<?php if ($isAdminAuthenticated && $newsPanelVisible): ?>
<section class="admin-panel news-admin-panel" id="news-panel" aria-labelledby="news-panel-title">
    <div class="admin-panel-header">
        <div>
            <p class="admin-panel-eyebrow">Administration</p>
            <h2 class="admin-panel-title" id="news-panel-title">Gestion des actualités</h2>
            <p class="admin-panel-text">Créez, modifiez et supprimez les articles de la page Actualités.</p>
        </div>
        <div class="admin-panel-header-actions">
            <a class="admin-utility-link" href="index.php?panel=1&tab=general#admin-panel">Pilotage du site</a>
            <a class="admin-utility-link" href="actualites.php">Retour aux actualités</a>
        </div>
    </div>

    <?php if ($flash !== []): ?>
    <div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
        <?php echo escape($flash['message'] ?? ''); ?>
    </div>
    <?php endif; ?>

    <!-- Formulaire ajout / modification -->
    <form method="post" class="admin-form-card news-article-form">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="save_news_article">
        <input type="hidden" name="news_id"      value="<?php echo escapeAttribute($editArticle['id'] ?? ''); ?>">

        <h3><?php echo $editArticle !== null ? 'Modifier l\'article' : 'Nouvel article'; ?></h3>
        <?php if ($editArticle !== null): ?>
        <p class="admin-form-text">
            Vous modifiez : <strong><?php echo escape($editArticle['title']); ?></strong>
            &nbsp;–&nbsp;<a href="actualites.php?news-panel=1#news-panel" style="color:#bae6fd">Annuler la modification</a>
        </p>
        <?php endif; ?>

        <div class="admin-form-grid">
            <label class="admin-field admin-field-full">
                <span>Titre <abbr title="obligatoire">*</abbr></span>
                <input type="text" name="news_title" value="<?php echo escapeAttribute($editArticle['title'] ?? ''); ?>" required placeholder="Titre de l'article…">
            </label>
            <label class="admin-field">
                <span>Catégorie</span>
                <input type="text" name="news_category"
                       value="<?php echo escapeAttribute($editArticle['category'] ?? ''); ?>"
                       placeholder="ex : Serveur, Médias, Annonces…"
                       list="news-categories-list">
                <datalist id="news-categories-list">
                    <?php foreach ($newsCategories as $ec): ?>
                    <option value="<?php echo escapeAttribute($ec); ?>">
                    <?php endforeach; ?>
                </datalist>
            </label>
            <label class="admin-field">
                <span>Date</span>
                <input type="date" name="news_date" value="<?php echo escapeAttribute($editArticle['date'] ?? date('Y-m-d')); ?>">
            </label>
            <label class="admin-field">
                <span>Image (URL ou assets/images/…)</span>
                <input type="text" name="news_image" value="<?php echo escapeAttribute($editArticle['image'] ?? ''); ?>" placeholder="https://… ou assets/images/…">
            </label>
            <label class="admin-field">
                <span>Vidéo (YouTube, Vimeo, ou .mp4 direct)</span>
                <input type="text" name="news_video" value="<?php echo escapeAttribute($editArticle['video'] ?? ''); ?>" placeholder="https://youtube.com/watch?v=… ou https://vimeo.com/… ou .mp4">
            </label>
            <label class="admin-field admin-field-full">
                <span>Résumé (affiché dans la liste)</span>
                <textarea name="news_summary" rows="2" placeholder="Courte description…"><?php echo escape($editArticle['summary'] ?? ''); ?></textarea>
            </label>
            <label class="admin-field admin-field-full">
                <span>Contenu détaillé</span>
                <textarea name="news_content" rows="6" placeholder="Contenu complet de l'article…"><?php echo escape($editArticle['content'] ?? ''); ?></textarea>
            </label>
            <label class="admin-field admin-field-checkbox">
                <input type="checkbox" name="news_visible" value="1" <?php echo ((int)($editArticle['visible'] ?? 1) === 1) ? 'checked' : ''; ?>>
                <span>Article visible par les visiteurs</span>
            </label>
            <label class="admin-field admin-field-checkbox">
                <input type="checkbox" name="news_pinned" value="1" <?php echo ((int)($editArticle['pinned'] ?? 0) === 1) ? 'checked' : ''; ?>>
                <span>Article épinglé (affiché en premier)</span>
            </label>
        </div>
        <div class="admin-form-actions">
            <button class="admin-save-button" type="submit">
                <?php echo $editArticle !== null ? 'Mettre à jour l\'article' : 'Publier l\'article'; ?>
            </button>
        </div>
    </form>

    <!-- Liste de gestion -->
    <?php if (!empty($newsArticles)): ?>
    <div class="admin-form-card">
        <h3>Articles existants</h3>
        <p class="admin-form-text"><?php echo count($newsArticles); ?> article(s) au total.</p>
        <ul class="news-manage-list">
        <?php foreach ($newsArticles as $a): ?>
        <li class="news-manage-row<?php echo (int)($a['visible'] ?? 0) === 0 ? ' is-hidden-row' : ''; ?>">
            <div class="news-manage-meta">
                <span class="news-manage-title"><?php echo escape($a['title'] ?? '(sans titre)'); ?></span>
                <span class="news-manage-info">
                    <?php echo escape($a['date'] ?? ''); ?>
                    <?php if ((int)($a['pinned'] ?? 0)): ?>&nbsp;📌<?php endif; ?>
                    <?php if ((int)($a['visible'] ?? 0) === 0): ?>&nbsp;<em>Masqué</em><?php endif; ?>
                </span>
            </div>
            <div class="news-manage-actions">
                <a class="news-admin-edit-btn" href="actualites.php?edit=<?php echo escape($a['id']); ?>&news-panel=1#news-panel">Modifier</a>
                <form method="post" class="admin-inline-form">
                    <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action" value="toggle_news_visible">
                    <input type="hidden" name="news_id"      value="<?php echo escapeAttribute($a['id']); ?>">
                    <button class="news-admin-toggle-btn" type="submit"><?php echo (int)($a['visible'] ?? 0) === 0 ? 'Publier' : 'Masquer'; ?></button>
                </form>
                <form method="post" class="admin-inline-form">
                    <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action" value="delete_news_article">
                    <input type="hidden" name="news_id"      value="<?php echo escapeAttribute($a['id']); ?>">
                    <button class="admin-delete-button" type="submit" style="min-height:36px;font-size:.85rem;padding:.5rem .8rem"
                            onclick="return confirm('Supprimer cet article ?')">Supprimer</button>
                </form>
            </div>
        </li>
        <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- ── Gestion des catégories ─────────────────────────────── -->
    <?php $catFlash = ($flash !== [] && isset($_GET['cat-tab'])); ?>
    <div class="admin-form-card news-cat-manager" style="margin-top:1.5rem">
        <div class="news-cat-manager-header">
            <h3>Gestion des catégories</h3>
            <span class="news-category-count"><?php echo count($newsCategories); ?> catégorie(s)</span>
        </div>
        <p class="admin-form-text">Impossible de supprimer une catégorie qui contient encore des articles.</p>

        <?php if ($catFlash): ?>
        <div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status" style="margin:0.75rem 0 0">
            <?php echo escape($flash['message'] ?? ''); ?>
        </div>
        <?php endif; ?>

        <form method="post" class="news-cat-add-form">
            <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="add_news_category">
            <input type="hidden" name="cat-tab"      value="1">
            <label class="admin-field" style="flex:1;min-width:0">
                <span>Nouvelle catégorie</span>
                <input type="text" name="new_category" placeholder="ex : Serveur, Médias, Annonces…" required>
            </label>
            <div class="admin-form-actions" style="margin-top:0;align-self:flex-end">
                <button class="admin-save-button" type="submit">Ajouter</button>
            </div>
        </form>

        <?php if (!empty($newsCategories)): ?>
        <ul class="news-cat-list">
            <?php foreach ($newsCategories as $cat): ?>
            <?php
                $articlesInCat = array_filter($newsArticles, fn($a) => ($a['category'] ?? '') === $cat);
                $catCount      = count($articlesInCat);
                $canDelete     = $catCount === 0;
            ?>
            <li class="news-cat-row">
                <span class="news-cat-row-name"><?php echo escape($cat); ?></span>
                <span class="news-cat-row-count<?php echo $canDelete ? '' : ' is-used'; ?>">
                    <?php echo $catCount > 0 ? $catCount . ' article' . ($catCount > 1 ? 's' : '') : 'vide'; ?>
                </span>
                <?php if ($canDelete): ?>
                <form method="post" class="admin-inline-form">
                    <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action"  value="delete_news_category">
                    <input type="hidden" name="del_category"  value="<?php echo escapeAttribute($cat); ?>">
                    <input type="hidden" name="cat-tab"       value="1">
                    <button class="admin-delete-button" type="submit"
                            style="min-height:30px;font-size:.76rem;padding:.25rem .6rem"
                            onclick="return confirm('Supprimer la catégorie &laquo; <?php echo escapeAttribute($cat); ?> &raquo; ?')">Supprimer</button>
                </form>
                <?php else: ?>
                <span class="news-cat-row-lock" title="Contient des articles — impossible de supprimer">🔒</span>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php else: ?>
        <p class="admin-form-text" style="margin-top:.75rem">Aucune catégorie créée pour l'instant.</p>
        <?php endif; ?>
    </div>

</section>
<?php endif; ?>

</main>

<!-- ── Modale admin ──────────────────────────────────────────────── -->
<div class="admin-modal<?php echo $shouldAutoOpenAdminModal ? ' is-open' : ''; ?>"
     data-admin-modal aria-hidden="<?php echo $shouldAutoOpenAdminModal ? 'false' : 'true'; ?>">
    <div class="admin-modal-backdrop" data-admin-close></div>
    <div class="admin-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="admin-modal-title2">
        <button class="admin-modal-close" type="button" aria-label="Fermer" data-admin-close>&#215;</button>
        <div class="admin-modal-content">
            <h2 class="admin-modal-title" id="admin-modal-title2"><?php echo escape($adminUi['modal_title'] ?? 'Espace administrateur'); ?></h2>
            <?php if ($isAdminAuthenticated): ?>
            <p class="admin-modal-text">Session admin active.</p>
            <nav class="admin-modal-links" aria-label="Boutons administrateur">
                <?php foreach ($adminLinks as $al): ?>
                <?php if (!isItemVisible($al) || !(int)($al['show_in_modal'] ?? 1)) { continue; } ?>
                <a class="admin-link admin-link-block" href="<?php echo escape($al['url'] ?? '#'); ?>" target="_blank" rel="noopener noreferrer"><?php echo escape($al['label'] ?? ''); ?></a>
                <?php endforeach; ?>
                <a class="admin-link admin-link-block" href="actualites.php?news-panel=1#news-panel">Gérer les actualités</a>
            </nav>
            <form method="post" class="admin-logout-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="logout">
                <button class="admin-logout-button" type="submit"><?php echo escape($adminUi['logout_label'] ?? 'Fermer la session admin'); ?></button>
            </form>
            <?php else: ?>
            <p class="admin-modal-text"><?php echo escape($adminUi['help_text'] ?? ''); ?></p>
            <?php if ($isLoginLocked): ?>
            <p class="admin-auth-error" role="alert">Trop de tentatives. Réessayez dans <?php echo $loginLockSecondsRemaining; ?> seconde(s).</p>
            <?php elseif ($adminAuthError !== ''): ?>
            <p class="admin-auth-error" role="alert"><?php echo escape($adminAuthError); ?></p>
            <?php endif; ?>
            <form method="post" class="admin-password-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="login">
                <label class="visually-hidden" for="admin-password2">Mot de passe administrateur</label>
                <input class="admin-password-input" id="admin-password2" name="admin_password"
                       type="password" autocomplete="current-password"
                       placeholder="<?php echo escapeAttribute($adminUi['password_placeholder'] ?? 'Mot de passe'); ?>"
                       <?php echo $isLoginLocked ? 'disabled' : 'required'; ?>>
                <button class="admin-password-submit" type="submit" <?php echo $isLoginLocked ? 'disabled' : ''; ?>>Ouvrir les boutons admin</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
(function(){
var modal=document.querySelector('[data-admin-modal]'),opens=document.querySelectorAll('[data-admin-open]'),closes=document.querySelectorAll('[data-admin-close]'),page=document.querySelector('.page'),pwd=document.getElementById('admin-password2');
if(!modal||!page||!opens.length)return;
function open(){modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('has-admin-modal-open');if(pwd)setTimeout(function(){pwd.focus();},40);}
function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('has-admin-modal-open');}
opens.forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();open();});});
closes.forEach(function(b){b.addEventListener('click',close);});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))close();});
if(page.getAttribute('data-admin-auto-open')==='1')open();
})();
(function(){
var btn=document.querySelector('[data-nav-hamburger]'),menu=document.querySelector('[data-nav-mobile-menu]');
if(!btn||!menu)return;
function toggle(){var open=btn.getAttribute('aria-expanded')==='true';btn.setAttribute('aria-expanded',open?'false':'true');menu.setAttribute('aria-hidden',open?'true':'false');menu.classList.toggle('is-open',!open);}
btn.addEventListener('click',toggle);
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&btn.getAttribute('aria-expanded')==='true')toggle();});
document.addEventListener('click',function(e){if(btn.getAttribute('aria-expanded')==='true'&&!btn.contains(e.target)&&!menu.contains(e.target))toggle();});
})();

(function(){
/* ── Accordéon catégories ── */
document.querySelectorAll('[data-cat-toggle]').forEach(function(btn) {
    var section = btn.closest('[data-cat-section]');
    var body    = section ? section.querySelector('.news-category-body') : null;
    if (!body) return;
    btn.addEventListener('click', function() {
        var open = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', open ? 'false' : 'true');
        body.setAttribute('aria-hidden', open ? 'true' : 'false');
        body.classList.toggle('is-open', !open);
        section.classList.toggle('is-expanded', !open);
    });
});
})();

(function(){
/* ── Modale article ── */
var modal     = document.getElementById('article-modal');
var backdrop  = document.getElementById('article-modal-backdrop');
var closeBtn  = document.getElementById('article-modal-close');
var imgEl     = document.getElementById('article-modal-img');
var dateEl    = document.getElementById('article-modal-date');
var pinnedEl  = document.getElementById('article-modal-pinned');
var titleEl   = document.getElementById('article-modal-title');
var summaryEl = document.getElementById('article-modal-summary');
var videoWrap = document.getElementById('article-modal-video-wrap');
var contentEl = document.getElementById('article-modal-content');
if (!modal) return;

// Fonction pour échapper le HTML
function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

var articlesMap = {};
if (typeof ARTICLES_DATA !== 'undefined') {
    ARTICLES_DATA.forEach(function(a){ articlesMap[a.id] = a; });
}

function buildVideoEmbed(url) {
    if (!url) return '';
    // YouTube
    var yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/);
    if (yt) return '<iframe src="https://www.youtube.com/embed/' + yt[1] + '?rel=0" allowfullscreen title="Vidéo YouTube" class="article-modal-iframe"></iframe>';
    // Vimeo
    var vi = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    if (vi) return '<iframe src="https://player.vimeo.com/video/' + vi[1] + '" allowfullscreen title="Vidéo Vimeo" class="article-modal-iframe"></iframe>';
    // Fichier vidéo direct
    if (/\.mp4|webm|ogg/i.test(url)) {
        return '<video controls class="article-modal-video"><source src="' + url + '"><p>Votre navigateur ne supporte pas la lecture vidéo.</p></video>';
    }
    return '';
}

function openModal(id) {
    var a = articlesMap[id];
    if (!a) return;
    // Image
    if (a.image) { imgEl.src = a.image; imgEl.style.display = 'block'; }
    else         { imgEl.style.display = 'none'; imgEl.src = ''; }
    // Meta
    dateEl.textContent = a.date;
    titleEl.textContent = a.title;
    if (pinnedEl) pinnedEl.style.display = a.pinned ? 'inline-flex' : 'none';
    // Summary
    if (a.summary) { summaryEl.textContent = a.summary; summaryEl.style.display = 'block'; }
    else           { summaryEl.style.display = 'none'; }
    // Video
    if (videoWrap) {
        var embed = buildVideoEmbed(a.video || '');
        if (embed) { videoWrap.innerHTML = embed; videoWrap.style.display = 'block'; }
        else       { videoWrap.innerHTML = ''; videoWrap.style.display = 'none'; }
    }
    // Content
    contentEl.innerHTML = a.content ? a.content.replace(/\n/g,'<br>') : '';
    
    // Commentaires
    var commentsListEl = document.getElementById('comments-list');
    var commentsCountEl = document.getElementById('comments-count');
    var commentArticleIdInput = document.getElementById('comment-article-id');
    
    // Mettre à jour l'ID de l'article dans le formulaire
    if (commentArticleIdInput) {
        commentArticleIdInput.value = a.id;
    }
    
    // Afficher les commentaires
    if (commentsListEl && commentsCountEl) {
        var comments = a.comments || [];
        commentsCountEl.textContent = '(' + comments.length + ')';
        
        if (comments.length === 0) {
            commentsListEl.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:2rem 0;">Aucun commentaire pour le moment. Soyez le premier à commenter !</p>';
        } else {
            var html = '';
            comments.forEach(function(c) {
                var statusBadge = '';
                var commentClass = 'comment-item';
                
                if (c.status === 'pending') {
                    statusBadge = '<span class="comment-status-badge status-pending">⏳ En attente de modération</span>';
                    commentClass += ' comment-pending';
                } else if (c.status === 'rejected') {
                    statusBadge = '<span class="comment-status-badge status-rejected">✕ Rejeté</span>';
                    commentClass += ' comment-rejected';
                }
                
                var date = new Date(c.created_at);
                var dateStr = date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                
                html += '<div class="' + commentClass + '">';
                html += '  <div class="comment-header">';
                html += '    <strong class="comment-author">' + escapeHtml(c.username) + '</strong>';
                html += '    <span class="comment-date">' + dateStr + '</span>';
                html += '    ' + statusBadge;
                html += '  </div>';
                html += '  <div class="comment-content">' + escapeHtml(c.content).replace(/\n/g, '<br>') + '</div>';
                html += '</div>';
            });
            commentsListEl.innerHTML = html;
        }
    }
    
    // Open
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
    modal.scrollTop = 0;
    closeBtn.focus();
}
function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow = '';
    // Stop video on close
    if (videoWrap) { videoWrap.innerHTML = ''; videoWrap.style.display = 'none'; }
}
document.querySelectorAll('[data-open-article]').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        openModal(btn.getAttribute('data-open-article'));
    });
});
closeBtn.addEventListener('click', closeModal);
backdrop.addEventListener('click', closeModal);
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeModal(); });
})();
</script>

<!-- ══════════════════════════════════════════════════════════════
     MODALES UTILISATEURS
     ══════════════════════════════════════════════════════════════ -->

<!-- Modale Connexion -->
<div class="user-modal<?php echo isset($_GET['show_login']) ? ' is-open' : ''; ?>" id="login-modal" data-user-modal="login">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Connexion</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['login_message'] ?? 'Connectez-vous pour accéder au site.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="login_user">
            
            <div class="user-field">
                <label for="login_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="login_username" 
                    name="login_username" 
                    placeholder="Votre nom d'utilisateur"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="login_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="login_password" 
                    name="login_password" 
                    placeholder="Votre mot de passe"
                    required
                    autocomplete="current-password"
                >
            </div>
            
            <button type="submit" class="user-submit-btn">Se connecter</button>
        </form>
        
        <?php if ($allowRegistration): ?>
        <div class="user-modal-footer">
            Pas encore de compte ? <button type="button" data-switch-to-register>S'inscrire</button>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modale Inscription -->
<?php if ($allowRegistration): ?>
<div class="user-modal<?php echo isset($_GET['show_register']) ? ' is-open' : ''; ?>" id="register-modal" data-user-modal="register">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Inscription</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['registration_message'] ?? 'Créez un compte pour accéder au contenu.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="register_user">
            
            <div class="user-field">
                <label for="register_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="register_username" 
                    name="register_username" 
                    placeholder="Minimum 3 caractères"
                    minlength="3"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="register_email">Email</label>
                <input 
                    type="email" 
                    id="register_email" 
                    name="register_email" 
                    placeholder="votre@email.com"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="register_password" 
                    name="register_password" 
                    placeholder="Minimum 6 caractères"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password_confirm">Confirmer le mot de passe</label>
                <input 
                    type="password" 
                    id="register_password_confirm" 
                    name="register_password_confirm" 
                    placeholder="Retapez votre mot de passe"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="discovered_from">Comment avez-vous connu ce site ? (optionnel)</label>
                <input 
                    type="text" 
                    id="discovered_from" 
                    name="discovered_from" 
                    placeholder="Google, Discord, un ami..."
                >
            </div>
            
            <button type="submit" class="user-submit-btn">S'inscrire</button>
        </form>
        
        <div class="user-modal-footer">
            Déjà un compte ? <button type="button" data-switch-to-login>Se connecter</button>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
/* ══════════════════════════════════════════════════════════════
   GESTION DES MODALES UTILISATEURS
   ══════════════════════════════════════════════════════════════ */
(function() {
    var loginModal = document.getElementById('login-modal');
    var registerModal = document.getElementById('register-modal');
    
    // Boutons d'ouverture
    var loginOpenBtns = document.querySelectorAll('[data-user-login-open]');
    var registerOpenBtns = document.querySelectorAll('[data-user-register-open]');
    
    // Boutons de fermeture
    var closeBtns = document.querySelectorAll('[data-user-modal-close]');
    
    // Boutons de bascule
    var switchToRegisterBtns = document.querySelectorAll('[data-switch-to-register]');
    var switchToLoginBtns = document.querySelectorAll('[data-switch-to-login]');
    
    // Fonctions d'ouverture/fermeture
    function openModal(modal) {
        if (modal) {
            modal.classList.add('is-open');
            document.body.style.overflow = 'hidden';
        }
    }
    
    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('is-open');
            document.body.style.overflow = '';
        }
    }
    
    function closeAllModals() {
        closeModal(loginModal);
        closeModal(registerModal);
    }
    
    // Ouvrir connexion
    loginOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(loginModal);
        });
    });
    
    // Ouvrir inscription
    registerOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(registerModal);
        });
    });
    
    // Fermer
    closeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var modal = btn.closest('[data-user-modal]');
            closeModal(modal);
        });
    });
    
    // Basculer vers inscription
    switchToRegisterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(loginModal);
            openModal(registerModal);
        });
    });
    
    // Basculer vers connexion
    switchToLoginBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(registerModal);
            openModal(loginModal);
        });
    });
    
    // Fermer au clic sur le backdrop
    [loginModal, registerModal].forEach(function(modal) {
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        }
    });
    
    // Fermer avec Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
})();
</script>

</body>
</html>
