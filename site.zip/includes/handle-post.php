<?php
/**
 * NéoPcPro – Gestionnaire d'actions POST admin
 * Inclure uniquement depuis index.php ou actualites.php.
 */
if (!defined('NEOPCPRO_LOADED')) {
    http_response_code(403);
    exit;
}

if ($requestMethod !== 'POST') {
    return;
}

/* ─── Vérification CSRF ───────────────────────────────────────────────── */
$submittedCsrfToken = (string) ($_POST['csrf_token'] ?? '');
if (!verifyCsrfToken($submittedCsrfToken)) {
    setFlash('error', 'La session de sécurité a expiré. Recharge la page puis recommence.');
    redirectToSelf();
}

$adminAction = (string) ($_POST['admin_action'] ?? '');

/* ─── Connexion ───────────────────────────────────────────────────────── */
if ($adminAction === 'login') {
    $submittedPassword = (string) ($_POST['admin_password'] ?? '');

    if ($isLoginLocked) {
        $adminAuthError = 'Trop de tentatives. Réessayez dans ' . $loginLockSecondsRemaining . ' seconde(s).';
        $shouldAutoOpenAdminModal = true;
    } elseif ($adminAccessPasswordHash === '') {
        $adminAuthError = 'Le mot de passe administrateur n\'est pas encore configuré.';
        $shouldAutoOpenAdminModal = true;
    } elseif (password_verify($submittedPassword, $adminAccessPasswordHash)) {
        $_SESSION[$adminSessionKey] = true;
        $_SESSION['login_attempts'] = 0;
        unset($_SESSION['login_locked_until']);
        session_regenerate_id(true);
        redirectToSelf(['admin' => '1']);
    } else {
        $attempts = (int) ($_SESSION['login_attempts'] ?? 0) + 1;
        $_SESSION['login_attempts'] = $attempts;
        if ($attempts >= 10) {
            $_SESSION['login_locked_until'] = time() + 300;
            $adminAuthError = 'Compte verrouillé 5 minutes après trop de tentatives.';
        } elseif ($attempts >= 5) {
            $_SESSION['login_locked_until'] = time() + 120;
            $adminAuthError = 'Mot de passe incorrect. Verrouillage 2 minutes après 5 tentatives.';
        } elseif ($attempts >= 3) {
            $_SESSION['login_locked_until'] = time() + 30;
            $adminAuthError = 'Mot de passe incorrect. Verrouillage 30 s après 3 tentatives.';
        } else {
            $adminAuthError = 'Mot de passe incorrect. (' . $attempts . ' tentative(s))';
        }
        $shouldAutoOpenAdminModal = true;
    }
}

/* ─── Déconnexion ─────────────────────────────────────────────────────── */
if ($adminAction === 'logout') {
    unset($_SESSION[$adminSessionKey]);
    session_regenerate_id(true);
    setFlash('success', 'La session administrateur a été fermée.');
    redirectToSelf();
}

/* ═══════════════════════════════════════════════════════════════════════
   ACTIONS UTILISATEURS (PUBLIQUES - Accessibles sans authentification)
   ═══════════════════════════════════════════════════════════════════════ */

/* ── Inscription utilisateur ──────────────────────────────────────────── */
if ($adminAction === 'register_user') {
    $username        = normalizeUsername($_POST['register_username'] ?? '');
    $email           = strtolower(trim($_POST['register_email'] ?? ''));
    $password        = (string)($_POST['register_password'] ?? '');
    $passwordConfirm = (string)($_POST['register_password_confirm'] ?? '');
    $discoveredFrom  = normalizeText($_POST['discovered_from'] ?? '');
    
    // Validations
    $errors = [];
    
    if ($username === '') {
        $errors[] = 'Le nom d\'utilisateur est requis.';
    } elseif (strlen($username) < 3) {
        $errors[] = 'Le nom d\'utilisateur doit contenir au moins 3 caractères.';
    } elseif (isUsernameTaken($username, $users)) {
        $errors[] = 'Ce nom d\'utilisateur est déjà pris.';
    }
    
    if ($email === '') {
        $errors[] = 'L\'email est requis.';
    } elseif (!isValidEmail($email)) {
        $errors[] = 'L\'email n\'est pas valide.';
    } elseif (isEmailTaken($email, $users)) {
        $errors[] = 'Cet email est déjà utilisé.';
    }
    
    if ($password === '') {
        $errors[] = 'Le mot de passe est requis.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Le mot de passe doit contenir au moins 6 caractères.';
    } elseif ($password !== $passwordConfirm) {
        $errors[] = 'Les mots de passe ne correspondent pas.';
    }
    
    if (!empty($errors)) {
        setFlash('error', implode(' ', $errors));
        redirectToSelf(['show_register' => '1']);
    }
    
    // Créer l'utilisateur
    $newUser = [
        'id'              => generateUserId(),
        'username'        => $username,
        'email'           => $email,
        'password_hash'   => hashUserPassword($password),
        'status'          => 'pending', // En attente de validation admin
        'role'            => 'user',
        'discovered_from' => $discoveredFrom,
        'created_at'      => date('Y-m-d H:i:s'),
        'validated_at'    => '',
        'last_login'      => '',
    ];
    
    $users[] = $newUser;
    
    if (writeJsonFile($usersPath, $users)) {
        $welcomeMsg = $userConfig['welcome_message'] ?? 'Votre inscription a été soumise et sera examinée par un administrateur.';
        setFlash('success', $welcomeMsg);
        redirectToSelf();
    } else {
        setFlash('error', 'Impossible d\'enregistrer votre inscription. ' . getWriteError());
        redirectToSelf(['show_register' => '1']);
    }
}

/* ── Connexion utilisateur ────────────────────────────────────────────── */
if ($adminAction === 'login_user') {
    $username = normalizeUsername($_POST['login_username'] ?? '');
    $password = (string)($_POST['login_password'] ?? '');
    
    if ($username === '' || $password === '') {
        setFlash('error', 'Nom d\'utilisateur et mot de passe requis.');
        redirectToSelf(['show_login' => '1']);
    }
    
    $user = findUserByUsername($username, $users);
    
    if (!$user) {
        setFlash('error', 'Identifiant ou mot de passe incorrect. Si vous venez de vous inscrire, votre compte est peut-être en attente de validation.');
        redirectToSelf(['show_login' => '1']);
    }
    
    if ($user['status'] === 'pending') {
        setFlash('warning', 'Votre compte est en attente de validation par un administrateur. Vous recevrez un accès dès validation.');
        redirectToSelf(['show_login' => '1']);
    }
    
    if ($user['status'] === 'banned') {
        setFlash('error', 'Votre compte a été banni. Veuillez contacter l\'administrateur.');
        redirectToSelf(['show_login' => '1']);
    }
    
    if (!verifyUserPassword($password, $user['password_hash'])) {
        setFlash('error', 'Identifiant ou mot de passe incorrect.');
        redirectToSelf(['show_login' => '1']);
    }
    
    // Connexion réussie
    loginUser($user);
    
    // Mettre à jour la date de dernière connexion
    foreach ($users as $key => $u) {
        if ($u['id'] === $user['id']) {
            $users[$key]['last_login'] = date('Y-m-d H:i:s');
            break;
        }
    }
    writeJsonFile($usersPath, $users);
    
    // Enregistrer dans l'historique
    logUserLogin($user['id'], $user['username'], $loginHistory, $loginHistoryPath);
    
    setFlash('success', 'Bienvenue ' . $user['username'] . ' !');
    redirectToSelf();
}

/* ── Déconnexion utilisateur ──────────────────────────────────────────── */
if ($adminAction === 'logout_user') {
    logoutUser();
    setFlash('success', 'Vous avez été déconnecté.');
    redirectToSelf();
}

/* ─── Actions réservées à l'admin authentifié ────────────────────────── */
if (!$isAdminAuthenticated) {
    return;
}

/* ── Paramètres généraux ─────────────────────────────────────────────── */
if ($adminAction === 'save_general') {
    $siteSettings['site_title']    = normalizeText($_POST['site_title']    ?? $siteSettings['site_title']);
    $siteSettings['site_subtitle'] = normalizeText($_POST['site_subtitle'] ?? $siteSettings['site_subtitle']);
    
    // Gérer l'image OG (select ou custom)
    $ogImageValue = normalizeText($_POST['og_image'] ?? '');
    if ($ogImageValue === 'custom') {
        $siteSettings['og_image'] = normalizeText($_POST['og_image_custom'] ?? '');
    } else {
        $siteSettings['og_image'] = $ogImageValue;
    }
    
    $siteSettings['admin_ui']['button_label']         = normalizeText($_POST['admin_button_label']         ?? '');
    $siteSettings['admin_ui']['modal_title']          = normalizeText($_POST['admin_modal_title']          ?? '');
    $siteSettings['admin_ui']['help_text']            = normalizeText($_POST['admin_help_text']            ?? '');
    $siteSettings['admin_ui']['password_placeholder'] = normalizeText($_POST['admin_password_placeholder'] ?? '');
    $siteSettings['admin_ui']['logout_label']         = normalizeText($_POST['admin_logout_label']         ?? '');
    $siteSettings['admin_ui']['dashboard_label']      = normalizeText($_POST['admin_dashboard_label']      ?? '');
    $siteSettings['admin_ui']['dashboard_title']      = normalizeText($_POST['admin_dashboard_title']      ?? '');
    $siteSettings['admin_ui']['dashboard_text']       = normalizeText($_POST['admin_dashboard_text']       ?? '');
    writeJsonFile($dataDir . '/site-settings.json', $siteSettings)
        ? setFlash('success', 'Les réglages généraux ont été enregistrés.')
        : setFlash('error',   'Impossible d\'enregistrer. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'general'], 'admin-panel');
}

/* ── Boutons principaux ──────────────────────────────────────────────── */
if ($adminAction === 'save_buttons') {
    $postedButtons = is_array($_POST['buttons'] ?? null) ? $_POST['buttons'] : [];
    $buttons = normalizeListItems($postedButtons, ['supportsType' => true, 'supportsIcon' => true, 'allowedTypes' => $buttonTypeOptions, 'allowedIcons' => $iconOptions, 'minimumRows' => 2]);
    writeJsonFile($dataDir . '/main-buttons.json', $buttons)
        ? setFlash('success', 'Les boutons principaux ont été mis à jour.')
        : setFlash('error',   'Impossible d\'enregistrer. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'buttons'], 'admin-panel');
}


/* ── Liens admin ─────────────────────────────────────────────────────── */
if ($adminAction === 'save_admin_links') {
    $adminLinks = normalizeListItems(is_array($_POST['admin_links'] ?? null) ? $_POST['admin_links'] : [], ['minimumRows' => 4, 'extraFields' => ['show_in_modal']]);
    writeJsonFile($dataDir . '/admin-links.json', $adminLinks)
        ? setFlash('success', 'Les liens administrateurs ont été mis à jour.')
        : setFlash('error',   'Impossible d\'enregistrer. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'admin-links'], 'admin-panel');
}

/* ── Maintenance ─────────────────────────────────────────────────────── */
if ($adminAction === 'save_maintenance') {
    $tipsLines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string)($_POST['maintenance_tips_lines'] ?? '')) ?: [])));
    $siteSettings['maintenance']['enabled']             = normalizeCheckbox($_POST['maintenance_enabled'] ?? '');
    $siteSettings['maintenance']['notice_title']        = normalizeText($_POST['maintenance_notice_title'] ?? '');
    $siteSettings['maintenance']['notice_text']         = normalizeText($_POST['maintenance_notice_text']  ?? '');
    $siteSettings['maintenance']['badge_text']          = normalizeText($_POST['maintenance_badge_text']   ?? '');
    $siteSettings['maintenance']['title']               = normalizeText($_POST['maintenance_title']        ?? '');
    $siteSettings['maintenance']['subtitle']            = normalizeText($_POST['maintenance_subtitle']     ?? '');
    $siteSettings['maintenance']['status_title']        = normalizeText($_POST['maintenance_status_title'] ?? '');
    $siteSettings['maintenance']['status_text']         = normalizeText($_POST['maintenance_status_text']  ?? '');
    $siteSettings['maintenance']['why_title']           = normalizeText($_POST['maintenance_why_title']    ?? '');
    $siteSettings['maintenance']['why_text']            = normalizeText($_POST['maintenance_why_text']     ?? '');
    $siteSettings['maintenance']['action_title']        = normalizeText($_POST['maintenance_action_title'] ?? '');
    $siteSettings['maintenance']['action_text']         = normalizeText($_POST['maintenance_action_text']  ?? '');
    $siteSettings['maintenance']['panel_message_title'] = normalizeText($_POST['maintenance_panel_message_title'] ?? '');
    $siteSettings['maintenance']['panel_message_text']  = normalizeText($_POST['maintenance_panel_message_text']  ?? '');
    $siteSettings['maintenance']['tips_title']          = normalizeText($_POST['maintenance_tips_title']   ?? '');
    $siteSettings['maintenance']['tips_lines']          = $tipsLines;
    $siteSettings['maintenance']['footer_note']         = normalizeText($_POST['maintenance_footer_note']  ?? '');
    $ok = writeJsonFile($dataDir . '/site-settings.json', $siteSettings);
    $ok ? setFlash('success', $siteSettings['maintenance']['enabled'] ? 'Mode maintenance activé.' : 'Mode maintenance désactivé.')
        : setFlash('error', 'Impossible d\'enregistrer. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'maintenance'], 'admin-panel');
}

/* ── Mot de passe ────────────────────────────────────────────────────── */
if ($adminAction === 'change_password') {
    $currentPwd  = (string) ($_POST['current_password']  ?? '');
    $newPwd      = (string) ($_POST['new_password']       ?? '');
    $confirmPwd  = (string) ($_POST['confirm_password']   ?? '');
    if ($adminAccessPasswordHash === '' || !password_verify($currentPwd, $adminAccessPasswordHash)) {
        setFlash('error', 'Le mot de passe actuel est incorrect.');
    } elseif (strlen($newPwd) < 4) {
        setFlash('error', 'Le nouveau mot de passe doit contenir au moins 4 caractères.');
    } elseif ($newPwd !== $confirmPwd) {
        setFlash('error', 'La confirmation ne correspond pas.');
    } else {
        $newHash = password_hash($newPwd, PASSWORD_DEFAULT);
        ($newHash !== false && writeAdminPasswordFile($adminCredentialsPath, $newHash))
            ? setFlash('success', 'Mot de passe mis à jour.')
            : setFlash('error',   'Impossible de mettre à jour. ' . getWriteError());
    }
    redirectToSelf(['panel' => '1', 'tab' => 'password'], 'admin-panel');
}

/* ── Upload d'asset ──────────────────────────────────────────────────── */
if ($adminAction === 'upload_asset') {
    $assetTarget  = (string) ($_POST['asset_target'] ?? 'icons');
    $targetDir    = $assetTarget === 'images' ? $imagesDir : $iconsDir;
    $publicPrefix = $assetTarget === 'images' ? 'assets/images' : 'assets/icons';
    $uploaded     = moveUploadedAsset($_FILES['asset_file'] ?? [], $targetDir, $publicPrefix, $allowedUploadExtensions, $maxUploadSizeBytes);
    $uploaded !== null
        ? setFlash('success', 'Le fichier ' . $uploaded['name'] . ' a été enregistré.')
        : setFlash('error',   'Impossible d\'envoyer le fichier. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'assets'], 'admin-panel');
}

/* ── Suppression d'asset ─────────────────────────────────────────────── */
if ($adminAction === 'delete_asset') {
    $assetTarget  = (string) ($_POST['asset_target'] ?? 'icons');
    $assetName    = (string) ($_POST['asset_name']   ?? '');
    $targetDir    = $assetTarget === 'images' ? $imagesDir : $iconsDir;
    $publicPrefix = $assetTarget === 'images' ? 'assets/images' : 'assets/icons';
    $deleted      = deleteManagedAsset($assetName, $targetDir, $publicPrefix);
    if ($deleted !== null) {
        $buttons = removeDeletedAssetReferences($buttons, $deleted['path']);
        $bOk = writeJsonFile($dataDir . '/main-buttons.json', $buttons);
        $bOk
            ? setFlash('success', 'Le fichier ' . $deleted['name'] . ' a été supprimé.')
            : setFlash('error',   'Fichier supprimé mais références non nettoyées. ' . getWriteError());
    } else {
        setFlash('error', 'Impossible de supprimer. ' . getWriteError());
    }
    redirectToSelf(['panel' => '1', 'tab' => 'assets'], 'admin-panel');
}

/* ── Actualités – enregistrer (créer ou modifier) ────────────────────── */
if ($adminAction === 'save_news_article') {
    $articleId  = normalizeText($_POST['news_id'] ?? '');
    $isEdit     = $articleId !== '';

    $articleData = [
        'id'       => $isEdit ? $articleId : generateNewsId(),
        'visible'  => normalizeCheckbox($_POST['news_visible']  ?? ''),
        'pinned'   => normalizeCheckbox($_POST['news_pinned']   ?? ''),
        'category' => normalizeText($_POST['news_category']     ?? ''),
        'title'    => normalizeText($_POST['news_title']    ?? ''),
        'summary'  => normalizeText($_POST['news_summary']  ?? ''),
        'content'  => normalizeText($_POST['news_content']  ?? ''),
        'date'     => normalizeText($_POST['news_date']     ?? date('Y-m-d')),
        'image'    => normalizeText($_POST['news_image']    ?? ''),
        'video'    => normalizeText($_POST['news_video']    ?? ''),
    ];

    if ($articleData['title'] === '') {
        setFlash('error', 'Le titre de l\'article est obligatoire.');
        redirectToSelf(['news-panel' => '1']);
    }

    if ($isEdit) {
        $found = false;
        foreach ($newsArticles as &$existing) {
            if ($existing['id'] === $articleId) {
                $existing = $articleData;
                $found    = true;
                break;
            }
        }
        unset($existing);
        if (!$found) {
            $newsArticles[] = $articleData;
        }
    } else {
        array_unshift($newsArticles, $articleData);
    }

    writeJsonFile($dataDir . '/news.json', $newsArticles)
        ? setFlash('success', $isEdit ? 'Article mis à jour.' : 'Article publié.')
        : setFlash('error',   'Impossible d\'enregistrer l\'article. ' . getWriteError());
    redirectToSelf(['news-panel' => '1']);
}

/* ── Actualités – supprimer ──────────────────────────────────────────── */
if ($adminAction === 'delete_news_article') {
    $deleteId     = normalizeText($_POST['news_id'] ?? '');
    $newsArticles = array_values(array_filter($newsArticles, fn($a) => $a['id'] !== $deleteId));
    writeJsonFile($dataDir . '/news.json', $newsArticles)
        ? setFlash('success', 'Article supprimé.')
        : setFlash('error',   'Impossible de supprimer. ' . getWriteError());
    redirectToSelf(['news-panel' => '1']);
}

/* ── Actualités – basculer visibilité ────────────────────────────────── */
if ($adminAction === 'toggle_news_visible') {
    $toggleId = normalizeText($_POST['news_id'] ?? '');
    foreach ($newsArticles as &$article) {
        if ($article['id'] === $toggleId) {
            $article['visible'] = $article['visible'] === 1 ? 0 : 1;
            break;
        }
    }
    unset($article);
    writeJsonFile($dataDir . '/news.json', $newsArticles)
        ? setFlash('success', 'Visibilité mise à jour.')
        : setFlash('error',   'Impossible de mettre à jour. ' . getWriteError());
    redirectToSelf(['news-panel' => '1']);
}

/* ── Téléchargements page – enregistrer ─────────────────────────────── */
if ($adminAction === 'save_dl_item') {
    $itemId  = normalizeText($_POST['dl_id'] ?? '');
    $isEdit  = $itemId !== '';

    $itemData = [
        'id'          => $isEdit ? $itemId : generateNewsId(),
        'visible'     => normalizeCheckbox($_POST['dl_visible']  ?? ''),
        'featured'    => normalizeCheckbox($_POST['dl_featured'] ?? ''),
        'category'    => normalizeText($_POST['dl_category']     ?? ''),
        'name'        => normalizeText($_POST['dl_name']         ?? ''),
        'description' => normalizeText($_POST['dl_description']  ?? ''),
        'version'     => normalizeText($_POST['dl_version']      ?? ''),
        'badge'       => normalizeText($_POST['dl_badge']        ?? ''),
        'url'         => normalizeText($_POST['dl_url']          ?? ''),
        'icon'        => normalizeText($_POST['dl_icon']         ?? ''),
        'order'       => (int) ($_POST['dl_order']               ?? 99),
    ];

    if ($itemData['name'] === '' || $itemData['url'] === '') {
        setFlash('error', 'Le nom et l\'URL du téléchargement sont obligatoires.');
        redirectToSelf(['dl-panel' => '1']);
    }

    if ($isEdit) {
        $found = false;
        foreach ($downloadsPage as &$existing) {
            if ($existing['id'] === $itemId) { $existing = $itemData; $found = true; break; }
        }
        unset($existing);
        if (!$found) { $downloadsPage[] = $itemData; }
    } else {
        $downloadsPage[] = $itemData;
    }

    usort($downloadsPage, fn($a, $b) => $a['order'] <=> $b['order']);

    writeJsonFile($dataDir . '/downloads-page.json', $downloadsPage)
        ? setFlash('success', $isEdit ? 'Téléchargement mis à jour.' : 'Téléchargement ajouté.')
        : setFlash('error',   'Impossible d\'enregistrer. ' . getWriteError());
    redirectToSelf(['dl-panel' => '1']);
}

/* ── Téléchargements page – supprimer ───────────────────────────────── */
if ($adminAction === 'delete_dl_item') {
    $deleteId     = normalizeText($_POST['dl_id'] ?? '');
    $downloadsPage = array_values(array_filter($downloadsPage, fn($i) => $i['id'] !== $deleteId));
    writeJsonFile($dataDir . '/downloads-page.json', $downloadsPage)
        ? setFlash('success', 'Téléchargement supprimé.')
        : setFlash('error',   'Impossible de supprimer. ' . getWriteError());
    redirectToSelf(['dl-panel' => '1']);
}

/* ── Téléchargements page – basculer visibilité ─────────────────────── */
if ($adminAction === 'toggle_dl_visible') {
    $toggleId = normalizeText($_POST['dl_id'] ?? '');
    foreach ($downloadsPage as &$item) {
        if ($item['id'] === $toggleId) { $item['visible'] = $item['visible'] === 1 ? 0 : 1; break; }
    }
    unset($item);
    writeJsonFile($dataDir . '/downloads-page.json', $downloadsPage)
        ? setFlash('success', 'Visibilité mise à jour.')
        : setFlash('error',   'Impossible de mettre à jour. ' . getWriteError());
    redirectToSelf(['dl-panel' => '1']);
}

/* ─────────────────────────────────────────────────────────────────
   Catégories d'actualités
───────────────────────────────────────────────────────────────── */
if ($adminAction === 'add_news_category') {
    $newCat = normalizeText($_POST['new_category'] ?? '');
    if ($newCat === '') {
        setFlash('error', 'Le nom de la catégorie est obligatoire.');
        redirectToSelf(['news-panel' => '1', 'cat-tab' => '1']);
    }
    if (in_array($newCat, $newsCategories, true)) {
        setFlash('error', 'Cette catégorie existe déjà.');
        redirectToSelf(['news-panel' => '1', 'cat-tab' => '1']);
    }
    $newsCategories[] = $newCat;
    sort($newsCategories);
    writeJsonFile($dataDir . '/news-categories.json', $newsCategories)
        ? setFlash('success', 'Catégorie ajoutée.')
        : setFlash('error',   'Impossible d\'enregistrer les catégories. ' . getWriteError());
    redirectToSelf(['news-panel' => '1', 'cat-tab' => '1']);
}

if ($adminAction === 'delete_news_category') {
    $delCat = normalizeText($_POST['del_category'] ?? '');
    if ($delCat === '') {
        redirectToSelf(['news-panel' => '1', 'cat-tab' => '1']);
    }
    // Sécurité : vérifier qu'aucun article n'utilise cette catégorie
    $usedBy = array_filter($newsArticles, fn($a) => ($a['category'] ?? '') === $delCat);
    if (!empty($usedBy)) {
        $count = count($usedBy);
        setFlash('error', 'Impossible de supprimer « ' . $delCat . ' » : ' . $count . ' article' . ($count > 1 ? 's' : '') . ' l\'utilise' . ($count > 1 ? 'nt' : '') . ' encore.');
        redirectToSelf(['news-panel' => '1', 'cat-tab' => '1']);
    }
    $newsCategories = array_values(array_filter($newsCategories, fn($c) => $c !== $delCat));
    writeJsonFile($dataDir . '/news-categories.json', $newsCategories)
        ? setFlash('success', 'Catégorie supprimée.')
        : setFlash('error',   'Impossible d\'enregistrer les catégories. ' . getWriteError());
    redirectToSelf(['news-panel' => '1', 'cat-tab' => '1']);
}

/* ═══════════════════════════════════════════════════════════════════════
   ACTIONS UTILISATEURS (ESPACE UTILISATEUR CONNECTÉ)
   ═══════════════════════════════════════════════════════════════════════ */

/* ── Modification du profil ───────────────────────────────────────────── */
if ($adminAction === 'update_profile' && $isUserAuthenticated) {
    $newEmail        = strtolower(trim($_POST['profile_email'] ?? ''));
    $newPassword     = (string)($_POST['profile_password'] ?? '');
    $confirmPassword = (string)($_POST['profile_password_confirm'] ?? '');
    
    $errors = [];
    
    // Valider l'email
    if ($newEmail === '') {
        $errors[] = 'L\'email est requis.';
    } elseif (!isValidEmail($newEmail)) {
        $errors[] = 'L\'email n\'est pas valide.';
    } elseif ($newEmail !== $currentUser['email'] && isEmailTaken($newEmail, $users, $currentUserId)) {
        $errors[] = 'Cet email est déjà utilisé par un autre compte.';
    }
    
    // Valider le mot de passe si fourni
    if ($newPassword !== '') {
        if (strlen($newPassword) < 6) {
            $errors[] = 'Le mot de passe doit contenir au moins 6 caractères.';
        } elseif ($newPassword !== $confirmPassword) {
            $errors[] = 'Les mots de passe ne correspondent pas.';
        }
    }
    
    if (!empty($errors)) {
        setFlash('error', implode(' ', $errors));
        redirectToSelf(['show_profile' => '1']);
    }
    
    // Mettre à jour l'utilisateur
    foreach ($users as $key => $user) {
        if ($user['id'] === $currentUserId) {
            $users[$key]['email'] = $newEmail;
            if ($newPassword !== '') {
                $users[$key]['password_hash'] = hashUserPassword($newPassword);
            }
            break;
        }
    }
    
    if (writeJsonFile($usersPath, $users)) {
        setFlash('success', 'Votre profil a été mis à jour.');
        redirectToSelf(['show_profile' => '1']);
    } else {
        setFlash('error', 'Impossible de mettre à jour votre profil. ' . getWriteError());
        redirectToSelf(['show_profile' => '1']);
    }
}

/* ── Suppression du compte ────────────────────────────────────────────── */
if ($adminAction === 'delete_account' && $isUserAuthenticated) {
    $password = (string)($_POST['delete_account_password'] ?? '');
    
    if (!verifyUserPassword($password, $currentUser['password_hash'])) {
        setFlash('error', 'Mot de passe incorrect.');
        redirectToSelf(['show_profile' => '1']);
    }
    
    // Supprimer l'utilisateur
    $users = array_values(array_filter($users, fn($u) => $u['id'] !== $currentUserId));
    
    // Supprimer ses commentaires
    $comments = array_values(array_filter($comments, fn($c) => $c['user_id'] !== $currentUserId));
    
    if (writeJsonFile($usersPath, $users) && writeJsonFile($commentsPath, $comments)) {
        logoutUser();
        setFlash('success', 'Votre compte a été supprimé.');
        redirectToSelf();
    } else {
        setFlash('error', 'Impossible de supprimer votre compte. ' . getWriteError());
        redirectToSelf(['show_profile' => '1']);
    }
}

/* ── Ajout d'un commentaire ───────────────────────────────────────────── */
if ($adminAction === 'add_comment' && $isUserAuthenticated) {
    $articleId = normalizeText($_POST['article_id'] ?? '');
    $content   = normalizeText($_POST['comment_content'] ?? '');
    
    if ($content === '') {
        setFlash('error', 'Le commentaire ne peut pas être vide.');
        redirectToSelf();
    }
    
    if (strlen($content) > 2000) {
        setFlash('error', 'Le commentaire est trop long (max 2000 caractères).');
        redirectToSelf();
    }
    
    $newComment = [
        'id'         => generateCommentId(),
        'article_id' => $articleId,
        'user_id'    => $currentUserId,
        'username'   => $currentUsername,
        'content'    => $content,
        'status'     => 'pending', // En attente de modération
        'created_at' => date('Y-m-d H:i:s'),
    ];
    
    $comments[] = $newComment;
    
    if (writeJsonFile($commentsPath, $comments)) {
        setFlash('success', 'Votre commentaire a été soumis et sera modéré par un administrateur.');
        redirectToSelf();
    } else {
        setFlash('error', 'Impossible d\'enregistrer votre commentaire. ' . getWriteError());
        redirectToSelf();
    }
}

/* ═══════════════════════════════════════════════════════════════════════
   ACTIONS ADMIN - GESTION DES UTILISATEURS
   ═══════════════════════════════════════════════════════════════════════ */
// Ces actions nécessitent l'authentification admin (déjà vérifiée plus haut)

/* ── Valider un utilisateur ───────────────────────────────────────────── */
if ($adminAction === 'validate_user') {
    $userId = normalizeText($_POST['user_id'] ?? '');
    
    foreach ($users as $key => $user) {
        if ($user['id'] === $userId) {
            $users[$key]['status'] = 'active';
            $users[$key]['validated_at'] = date('Y-m-d H:i:s');
            break;
        }
    }
    
    writeJsonFile($usersPath, $users)
        ? setFlash('success', 'Utilisateur validé.')
        : setFlash('error', 'Impossible de valider. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}

/* ── Refuser un utilisateur ───────────────────────────────────────────── */
if ($adminAction === 'reject_user') {
    $userId = normalizeText($_POST['user_id'] ?? '');
    
    $users = array_values(array_filter($users, fn($u) => $u['id'] !== $userId));
    
    writeJsonFile($usersPath, $users)
        ? setFlash('success', 'Utilisateur refusé et supprimé.')
        : setFlash('error', 'Impossible de refuser. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}

/* ── Bannir un utilisateur ────────────────────────────────────────────── */
if ($adminAction === 'ban_user') {
    $userId = normalizeText($_POST['user_id'] ?? '');
    
    foreach ($users as $key => $user) {
        if ($user['id'] === $userId) {
            $users[$key]['status'] = 'banned';
            break;
        }
    }
    
    writeJsonFile($usersPath, $users)
        ? setFlash('success', 'Utilisateur banni.')
        : setFlash('error', 'Impossible de bannir. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}

/* ── Débannir un utilisateur ──────────────────────────────────────────── */
if ($adminAction === 'unban_user') {
    $userId = normalizeText($_POST['user_id'] ?? '');
    
    foreach ($users as $key => $user) {
        if ($user['id'] === $userId) {
            $users[$key]['status'] = 'active';
            break;
        }
    }
    
    writeJsonFile($usersPath, $users)
        ? setFlash('success', 'Utilisateur débanni.')
        : setFlash('error', 'Impossible de débannir. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}

/* ── Supprimer un utilisateur ─────────────────────────────────────────── */
if ($adminAction === 'delete_user') {
    $userId = normalizeText($_POST['user_id'] ?? '');
    
    $users = array_values(array_filter($users, fn($u) => $u['id'] !== $userId));
    $comments = array_values(array_filter($comments, fn($c) => $c['user_id'] !== $userId));
    
    if (writeJsonFile($usersPath, $users) && writeJsonFile($commentsPath, $comments)) {
        setFlash('success', 'Utilisateur et ses commentaires supprimés.');
    } else {
        setFlash('error', 'Impossible de supprimer. ' . getWriteError());
    }
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}

/* ── Purger l'historique de connexion ─────────────────────────────────── */
if ($adminAction === 'purge_login_history') {
    purgeLoginHistory($loginHistoryPath)
        ? setFlash('success', 'Historique de connexion purgé.')
        : setFlash('error', 'Impossible de purger. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}

/* ── Approuver un commentaire ─────────────────────────────────────────── */
if ($adminAction === 'approve_comment') {
    $commentId = normalizeText($_POST['comment_id'] ?? '');
    
    foreach ($comments as $key => $comment) {
        if ($comment['id'] === $commentId) {
            $comments[$key]['status'] = 'approved';
            break;
        }
    }
    
    writeJsonFile($commentsPath, $comments)
        ? setFlash('success', 'Commentaire approuvé.')
        : setFlash('error', 'Impossible d\'approuver. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'comments'], 'admin-panel');
}

/* ── Rejeter un commentaire ───────────────────────────────────────────── */
if ($adminAction === 'reject_comment') {
    $commentId = normalizeText($_POST['comment_id'] ?? '');
    
    foreach ($comments as $key => $comment) {
        if ($comment['id'] === $commentId) {
            $comments[$key]['status'] = 'rejected';
            break;
        }
    }
    
    writeJsonFile($commentsPath, $comments)
        ? setFlash('success', 'Commentaire rejeté.')
        : setFlash('error', 'Impossible de rejeter. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'comments'], 'admin-panel');
}

/* ── Supprimer un commentaire ─────────────────────────────────────────── */
if ($adminAction === 'delete_comment') {
    $commentId = normalizeText($_POST['comment_id'] ?? '');
    
    $comments = array_values(array_filter($comments, fn($c) => $c['id'] !== $commentId));
    
    writeJsonFile($commentsPath, $comments)
        ? setFlash('success', 'Commentaire supprimé.')
        : setFlash('error', 'Impossible de supprimer. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'comments'], 'admin-panel');
}

/* ── Configuration utilisateurs ───────────────────────────────────────── */
if ($adminAction === 'save_user_config') {
    $userConfig['private_mode_enabled']     = normalizeCheckbox($_POST['private_mode_enabled'] ?? 0);
    $userConfig['allow_registration']       = normalizeCheckbox($_POST['allow_registration'] ?? 0);
    $userConfig['registration_message']     = normalizeText($_POST['registration_message'] ?? '');
    $userConfig['login_message']            = normalizeText($_POST['login_message'] ?? '');
    $userConfig['require_email_validation'] = normalizeCheckbox($_POST['require_email_validation'] ?? 0);
    $userConfig['welcome_message']          = normalizeText($_POST['welcome_message'] ?? '');
    
    writeJsonFile($userConfigPath, $userConfig)
        ? setFlash('success', 'Configuration utilisateurs enregistrée.')
        : setFlash('error', 'Impossible d\'enregistrer. ' . getWriteError());
    redirectToSelf(['panel' => '1', 'tab' => 'users'], 'admin-panel');
}
