<?php
/**
 * NéoPcPro – Fonctions de gestion des utilisateurs
 * Système complet d'inscription, connexion, profils et modération
 */

if (!defined('NEOPCPRO_LOADED')) {
    http_response_code(403);
    exit;
}

/* ═══════════════════════════════════════════════════════════════
   CONSTANTES ET STRUCTURES PAR DÉFAUT
   ═══════════════════════════════════════════════════════════════ */

$defaultUsers = [];
$defaultLoginHistory = [];
$defaultComments = [];

/* ═══════════════════════════════════════════════════════════════
   FONCTIONS UTILITAIRES
   ═══════════════════════════════════════════════════════════════ */

/**
 * Génère un ID unique pour un utilisateur
 */
function generateUserId(): string
{
    return bin2hex(random_bytes(6)); // 12 caractères hexadécimaux
}

/**
 * Génère un ID unique pour un commentaire
 */
function generateCommentId(): string
{
    return bin2hex(random_bytes(6));
}

/**
 * Hash sécurisé d'un mot de passe
 */
function hashUserPassword(string $password): string
{
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Vérifie un mot de passe contre son hash
 */
function verifyUserPassword(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}

/**
 * Valide un email
 */
function isValidEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Normalise un pseudo (alphanumérique, tirets, underscores)
 */
function normalizeUsername(string $username): string
{
    $username = trim($username);
    // Permet lettres, chiffres, tirets, underscores, accents
    $username = preg_replace('/[^\p{L}\p{N}_-]/u', '', $username);
    return $username;
}

/**
 * Vérifie si un pseudo est déjà utilisé
 */
function isUsernameTaken(string $username, array $users, ?string $excludeUserId = null): bool
{
    $normalized = strtolower(normalizeUsername($username));
    foreach ($users as $user) {
        if ($excludeUserId !== null && $user['id'] === $excludeUserId) {
            continue; // Ignorer l'utilisateur en cours d'édition
        }
        if (strtolower($user['username']) === $normalized) {
            return true;
        }
    }
    return false;
}

/**
 * Vérifie si un email est déjà utilisé
 */
function isEmailTaken(string $email, array $users, ?string $excludeUserId = null): bool
{
    $normalized = strtolower(trim($email));
    foreach ($users as $user) {
        if ($excludeUserId !== null && $user['id'] === $excludeUserId) {
            continue;
        }
        if (strtolower($user['email']) === $normalized) {
            return true;
        }
    }
    return false;
}

/**
 * Trouve un utilisateur par son ID
 */
function findUserById(string $userId, array $users): ?array
{
    foreach ($users as $user) {
        if ($user['id'] === $userId) {
            return $user;
        }
    }
    return null;
}

/**
 * Trouve un utilisateur par son username
 */
function findUserByUsername(string $username, array $users): ?array
{
    $normalized = strtolower(normalizeUsername($username));
    foreach ($users as $user) {
        if (strtolower($user['username']) === $normalized) {
            return $user;
        }
    }
    return null;
}

/**
 * Trouve un utilisateur par son email
 */
function findUserByEmail(string $email, array $users): ?array
{
    $normalized = strtolower(trim($email));
    foreach ($users as $user) {
        if (strtolower($user['email']) === $normalized) {
            return $user;
        }
    }
    return null;
}

/**
 * Compte le nombre d'inscriptions en attente de validation
 */
function countPendingUsers(array $users): int
{
    $count = 0;
    foreach ($users as $user) {
        if ($user['status'] === 'pending') {
            $count++;
        }
    }
    return $count;
}

/**
 * Normalise les données utilisateurs
 */
function normalizeUsers(array $rows): array
{
    $users = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        
        $users[] = [
            'id'              => normalizeText($row['id'] ?? generateUserId()),
            'username'        => normalizeUsername($row['username'] ?? ''),
            'email'           => strtolower(trim($row['email'] ?? '')),
            'password_hash'   => normalizeText($row['password_hash'] ?? ''),
            'status'          => in_array($row['status'] ?? 'pending', ['pending', 'active', 'banned']) ? $row['status'] : 'pending',
            'role'            => in_array($row['role'] ?? 'user', ['user', 'admin']) ? $row['role'] : 'user',
            'discovered_from' => normalizeText($row['discovered_from'] ?? ''),
            'created_at'      => normalizeText($row['created_at'] ?? date('Y-m-d H:i:s')),
            'validated_at'    => normalizeText($row['validated_at'] ?? ''),
            'last_login'      => normalizeText($row['last_login'] ?? ''),
        ];
    }
    return $users;
}

/**
 * Normalise l'historique de connexion
 */
function normalizeLoginHistory(array $rows): array
{
    $history = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        
        $history[] = [
            'user_id'    => normalizeText($row['user_id'] ?? ''),
            'username'   => normalizeText($row['username'] ?? ''),
            'timestamp'  => normalizeText($row['timestamp'] ?? date('Y-m-d H:i:s')),
            'ip_address' => normalizeText($row['ip_address'] ?? ''),
            'user_agent' => normalizeText($row['user_agent'] ?? ''),
        ];
    }
    
    // Trier par date décroissante
    usort($history, function($a, $b) {
        return strcmp($b['timestamp'], $a['timestamp']);
    });
    
    return $history;
}

/**
 * Normalise les commentaires
 */
function normalizeComments(array $rows): array
{
    $comments = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        
        $comments[] = [
            'id'         => normalizeText($row['id'] ?? generateCommentId()),
            'article_id' => normalizeText($row['article_id'] ?? ''),
            'user_id'    => normalizeText($row['user_id'] ?? ''),
            'username'   => normalizeText($row['username'] ?? ''),
            'content'    => normalizeText($row['content'] ?? ''),
            'status'     => in_array($row['status'] ?? 'pending', ['pending', 'approved', 'rejected']) ? $row['status'] : 'pending',
            'created_at' => normalizeText($row['created_at'] ?? date('Y-m-d H:i:s')),
        ];
    }
    
    // Trier par date décroissante
    usort($comments, function($a, $b) {
        return strcmp($b['created_at'], $a['created_at']);
    });
    
    return $comments;
}

/**
 * Enregistre une connexion dans l'historique
 */
function logUserLogin(string $userId, string $username, array &$loginHistory, string $historyPath): bool
{
    $entry = [
        'user_id'    => $userId,
        'username'   => $username,
        'timestamp'  => date('Y-m-d H:i:s'),
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
    ];
    
    array_unshift($loginHistory, $entry);
    
    // Limiter à 500 entrées max pour éviter un fichier trop lourd
    if (count($loginHistory) > 500) {
        $loginHistory = array_slice($loginHistory, 0, 500);
    }
    
    return writeJsonFile($historyPath, $loginHistory);
}

/**
 * Purge l'historique des connexions
 */
function purgeLoginHistory(string $historyPath): bool
{
    return writeJsonFile($historyPath, []);
}

/**
 * Compte le nombre de commentaires en attente de modération
 */
function countPendingComments(array $comments): int
{
    $count = 0;
    foreach ($comments as $comment) {
        if ($comment['status'] === 'pending') {
            $count++;
        }
    }
    return $count;
}

/**
 * Obtient les commentaires pour un article donné
 */
function getCommentsForArticle(string $articleId, array $comments, bool $includeAll = false): array
{
    $filtered = [];
    foreach ($comments as $comment) {
        if ($comment['article_id'] !== $articleId) {
            continue;
        }
        
        // Si admin, montrer tous les commentaires
        // Sinon, ne montrer que les approuvés
        if ($includeAll || $comment['status'] === 'approved') {
            $filtered[] = $comment;
        }
    }
    return $filtered;
}

/**
 * Vérifie si un utilisateur est authentifié
 */
function isUserAuthenticated(): bool
{
    return !empty($_SESSION['user_id']) && !empty($_SESSION['username']);
}

/**
 * Obtient l'ID de l'utilisateur connecté
 */
function getCurrentUserId(): ?string
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Obtient le username de l'utilisateur connecté
 */
function getCurrentUsername(): ?string
{
    return $_SESSION['username'] ?? null;
}

/**
 * Connecte un utilisateur
 */
function loginUser(array $user): void
{
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['user_role'] = $user['role'];
}

/**
 * Déconnecte un utilisateur
 */
function logoutUser(): void
{
    unset($_SESSION['user_id']);
    unset($_SESSION['username']);
    unset($_SESSION['user_role']);
}

/**
 * Vérifie si le site est en mode privé et redirige si nécessaire
 */
function enforcePrivateAccess(bool $isPrivate, bool $isUserAuth, bool $isAdminAuth, array $allowedPaths = []): void
{
    if (!$isPrivate) {
        return; // Site public, pas de restriction
    }
    
    // Admin toujours autorisé
    if ($isAdminAuth) {
        return;
    }
    
    // Utilisateur connecté autorisé
    if ($isUserAuth) {
        return;
    }
    
    // Vérifier si la page actuelle est autorisée (inscription, etc.)
    $currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    $basename = basename($currentPath);
    
    if (in_array($basename, $allowedPaths, true)) {
        return;
    }
    
    // Sinon, rediriger vers la page de connexion
    if ($basename !== 'index.php' && $basename !== '') {
        header('Location: /index.php?need_login=1');
        exit;
    }
}
